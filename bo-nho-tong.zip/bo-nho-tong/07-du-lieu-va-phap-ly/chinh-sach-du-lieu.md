# Chính sách dữ liệu

## Trạng thái: [CHƯA LÀM]

## Cần có trước khi thu thập thông tin khách
- Dữ liệu thu thập: họ tên và ngày sinh (của người lớn và trẻ em), kênh liên hệ.
- Mục đích: chỉ dùng cho buổi trao đổi.
- Sự đồng ý: phụ huynh đồng ý trước khi nhận thông tin của con.
- Lưu trữ: ở đâu, ai được truy cập.
- Thời hạn lưu và cách xoá theo yêu cầu.
- Không chia sẻ cho bên thứ ba, trừ khi có đồng ý riêng.

## Lưu ý
- Cần kiểm tra quy định pháp lý hiện hành về dữ liệu cá nhân và trẻ em. Tài liệu này không thay thế tư vấn pháp lý.
- Nếu bot AI nhận thông tin, cần ghi rõ điều này trong lời chào.
