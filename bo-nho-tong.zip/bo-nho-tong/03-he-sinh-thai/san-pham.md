# Hệ sinh thái sản phẩm

| Sản phẩm | Ai vào | Nội dung | Đầu ra mong đợi | Trạng thái |
|---|---|---|---|---|
| Bot miễn phí | Mọi người. Lời chào phân đối tượng trước | Luận cơ bản (kim tự tháp, tính cơ bản). Chưa luận 3×3 cho đến khi đối chiếu xong | Khách tò mò hơn, muốn tìm hiểu gói. Bấm link hoặc nhắn riêng là xong nhiệm vụ | [ĐỀ XUẤT] |
| Bot nâng cao | Khách đã nhắn riêng hoặc xem một buổi đầu. Chưa mua đồng hành, chưa muốn chuyên sâu | Mở thêm các link nâng cao | Khách tự tìm hiểu tiếp, cân nhắc khi cần người đi cùng | [CHỐT] cấu trúc. [CHƯA RÕ] cơ chế nhận biết khách |
| Khoá đồng hành online | Ba mẹ muốn đi cùng qua Zoom | Ba mẹ tự học, tự thực hành | Ba mẹ biết tự quan sát và thử ở nhà | [CHỐT] hình thức. [CHƯA RÕ] số buổi, giá |
| Khoá đồng hành offline | Ba mẹ muốn người đến trực tiếp | Thoả thuận lịch. Người đồng hành đến, giải thích vì sao con làm như vậy, hỗ trợ ba mẹ | Ba mẹ hiểu hành vi của con và biết phản ứng | [CHỐT] vai trò. [CHƯA RÕ] phạm vi đến nhà |
| Khoá chuyên sâu | Chưa xác định | Tuỳ phân tích đối tượng | Chưa xác định | [CHƯA LÀM] |

## Phân biệt
- [CHỐT] Bot miễn phí và bot nâng cao khác nhau ở phần luận 3×3 và các link mở thêm.
- [CHỐT] Online và offline cùng nội dung nền. Khác ở cách triển khai và mức ba mẹ tự làm.
- [CHỐT] Khoá chuyên sâu chờ phân tích đối tượng.

## Đường đi của khách
Bot miễn phí → (muốn tìm hiểu thêm) → nhắn riêng hoặc Zalo → buổi đầu riêng → bot nâng cao → (cần đồng hành) → khoá online hoặc offline → (cần chuyên sâu) → khoá chuyên sâu.

## Việc còn thiếu
- [CHƯA RÕ] Nền tảng bot miễn phí: Zalo OA, Messenger, website hay Telegram.
- [CHƯA RÕ] Zalo của người vận hành là tài khoản cá nhân hay Zalo OA.
- [CHƯA RÕ] Cơ chế bot nâng cao biết khách đã nhắn riêng hoặc đã xem buổi đầu.
- [CHƯA RÕ] Nghĩa của "kim tự tháp" trong mô tả bot.
- [CHƯA RÕ] Chi tiết khoá online và offline: số buổi, thời lượng, sĩ số, giá, lịch.
