# Tài sản nhận diện và bộ thẻ

## Thư viện tài sản [ĐỀ XUẤT]
- Thư viện A, kiến thức: ý nghĩa số 1–9; số chủ đạo; biểu đồ 3×3; số thiếu, trống, lặp; khác nhau giữa số từ tên và từ ngày sinh; ưu điểm và nhược điểm; vì sao luận có thể chưa khớp; cách tự quan sát.
- Thư viện B, cá nhân hoá: template bản đồ 3×3; recap sau buổi; ghi chú cá nhân; trạng thái "đã xác nhận / chưa xác nhận / cần quan sát thêm".
- Thư viện C, worksheet: bản thân, tình yêu, con cái, sự nghiệp, học tập, quyết định cụ thể.
- Thư viện D, đồng hành: goal sheet, daily tracker, weekly review, nhật ký hành vi, bài tập, progress report, end-of-program review.

## Bảng 3×3 cá nhân hai mặt [ĐỀ XUẤT]
Mặt trước: bảng 3×3, số chủ đạo, điểm nổi bật để nhìn nhanh. Mặt sau: chỗ người xem và khách ghi chú sau phiên. Vừa là quà, vừa là vật nhận diện.
[CHƯA RÕ] Luận 3×3 cần đối chiếu bảng tra trước khi in.

## Thẻ "Tên của bạn nói gì?" [ĐỀ XUẤT]
Mặt trước làm nổi bật tên. Mặt sau: nghĩa Hán-Việt hoặc ý nghĩa tên, đặc tính thường được liên tưởng, lưu ý, câu hỏi "Bạn có thấy mình như vậy không?", và nhắc rằng tên chỉ là điểm bắt đầu trước khi đối chiếu biểu đồ.

## Thẻ kết quả sau buổi [ĐỀ XUẤT]
Cấu trúc: 3 điều tôi thấy ở bạn; 1 điều bạn đã xác nhận; 1 điều chưa khớp; 1 điều nên quan sát thêm; gợi ý phát triển; câu hỏi tự suy ngẫm. Điểm "chưa khớp" giữ mở, không ép khách nhận.

## Thẻ giới thiệu / tặng bạn bè [ĐỀ XUẤT]
Sau buổi, khách có thể tặng một người bạn một lượt lập bản đồ 3×3 hoặc phiên bản quà giới thiệu. Thẻ có QR hoặc đường dẫn, hướng dẫn gửi tên và ngày sinh, và mô tả người nhận được gì.

## Hướng dẫn đọc kết quả [ĐỀ XUẤT]
Con số không quyết định người đó là ai. Có, thiếu, nhiều đều có ý nghĩa khác nhau, không tốt hay xấu tuyệt đối. Cần đối chiếu đời thật. Khách có quyền thấy luận giải không đúng với mình. Không dùng để phán xét người khác.

## Bộ thẻ theo chủ đề PR [ĐỀ XUẤT]
Dùng để đăng mạng xã hội, đặt tại bàn, tặng khách hoặc workshop. Mặt trước là câu hỏi, mặt sau là nội dung khám phá. Xem `02-doi-tuong/noi-dung-pr-va-cay-chu-de.md`.
