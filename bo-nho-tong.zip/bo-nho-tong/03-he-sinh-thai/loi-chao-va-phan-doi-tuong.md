# Lời chào bot và phân đối tượng

## Yêu cầu [ĐỀ XUẤT]
- Nói rõ bot là AI.
- Hỏi đối tượng ngay từ đầu. Hiện chỉ có nhóm phụ huynh có con.
- Gợi ý tư vấn riêng qua Zalo khi có tín hiệu cụ thể. Không lặp lại liên tục.
- Không luận cá tính trẻ em. Chỉ giải thích khung chung và dẫn sang buổi riêng.

## Luồng đề xuất
1. Chào, nói rõ là AI.
2. Hỏi: đang tìm hiểu cho ai (con, bản thân, hay khác).
3. Nếu là phụ huynh có con: đưa khung chung, hỏi con đang lớp mấy.
4. Đưa ba lựa chọn: tìm hiểu thêm, tư vấn riêng qua Zalo, xem gói.

## Chưa có
- [CHƯA LÀM] Hội thoại thật.
- [CHƯA RÕ] Phân nhóm đối tượng ngoài phụ huynh.
