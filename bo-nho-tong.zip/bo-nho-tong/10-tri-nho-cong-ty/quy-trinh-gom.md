# Trí nhớ công ty: quy trình gom

Mục đích: giữ kinh nghiệm và quyết định đã phát sinh, không để chúng nằm rải rác trong chat và ghi chú.

Khác với bản đồ: trí nhớ tăng hằng ngày. Cần gom liên tục, theo nhịp cố định.

## Nguồn cần gom
- Chat với AI: đoạn có quyết định, tình huống khó, cách xử lý đã thử.
- Tin nhắn Zalo và Messenger với khách: phản hồi, câu hỏi lặp lại, chỗ khách hiểu sai.
- Ghi chú sau phiên: điều đã thấy, điều chưa khớp, việc cần theo dõi.
- Quyết định bằng lời: thứ được chốt trong cuộc gọi hoặc khi tự suy nghĩ.

## Nhịp gom
| Tần suất | Việc | Thời lượng |
|---|---|---|
| Hằng ngày | Ghi nhanh vào `inbox.md`: một dòng một việc, không sửa | 10 phút |
| Cuối tuần | Chuyển các dòng trong inbox sang đúng file: quyết định vào nhật ký, tình huống vào trí nhớ, câu hỏi vào câu hỏi mở | 30 phút |
| Hằng tháng | Rà bản đồ: có thực thể hoặc luật nào đã đổi không. Cập nhật `09-ban-do-cong-ty/ontology.md` | 1 giờ |

## Quy tắc ghi
- Mỗi dòng có ngày, nhãn [CHỐT], [ĐỀ XUẤT], hoặc [CHƯA RÕ].
- Không ghi tên trẻ, số điện thoại, ngày sinh cụ thể của khách. Dùng mã (ví dụ: KH-001).
- Tình huống khó: ghi việc đã xảy ra, cách xử lý, kết quả. Không ghi đánh giá về người.
- Không sửa dòng cũ. Thêm dòng mới và đánh dấu [ĐÃ THAY].

## Mẫu dòng trong inbox
- 2026-11-14 | KH-001 hỏi về hoàn tiền | đã trả lời theo mục "Chưa chốt", chờ quyết định | [CHƯA RÕ]

## Khi nào chuyển sang bản đồ
Một tình huống lặp lại từ ba lần trở lên, hoặc có một quy tắc mới được chốt, thì chuyển thành luật trong `ontology.md`.

## Trạng thái
[ĐỀ XUẤT] Chưa có inbox. Tạo file khi bắt đầu ghi.
