# Mẫu landing

1. Hero: một câu hỏi về nỗi đau cụ thể, một câu ranh giới, một CTA.
2. Băn khoăn của khách.
3. Cách tiếp cận và ranh giới.
4. Điều khách nhận được.
5. Cách bắt đầu. Nếu chưa có giá, ghi [CHƯA RÕ].
6. Câu hỏi thường gặp.
7. Phản hồi thật (chỉ khi có đồng ý).
8. CTA và thông tin liên hệ.
