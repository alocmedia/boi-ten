# Mẫu chân dung khách

- Đối tượng:
- Ai là người quyết định mua:
- Băn khoăn chính:
- Lý do tìm đến:
- Rào cản mua:
- Không phải khách của dịch vụ:
- Ngôn ngữ nên dùng / tránh:
- Nguồn: [CHỐT] tài liệu / [ĐỀ XUẤT] suy luận / [CHƯA RÕ]
