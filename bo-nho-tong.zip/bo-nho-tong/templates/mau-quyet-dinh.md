# Mẫu ghi quyết định

- Ngày: YYYY-MM-DD
- Vấn đề:
- Phương án được chọn: [CHỐT]
- Phương án bị loại:
- Lý do:
- File bị ảnh hưởng:
- Việc cần làm tiếp:
