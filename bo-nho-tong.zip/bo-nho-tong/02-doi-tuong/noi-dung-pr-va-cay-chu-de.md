# Nội dung PR và cây chủ đề

## Nguyên tắc [CHỐT]
- Chủ đề PR là cửa vào để khách dễ nhận ra nhu cầu. Không đồng nghĩa dịch vụ dự đoán tương lai.
- Engine bên trong khác: tên/thần số học → giải thích → đối chiếu → hiểu → lựa chọn → hành động.

## Chủ đề PR thường gặp [CHỐT, từ tài liệu]
Tình duyên, sự nghiệp, bản thân, con cái, gia đình, mối quan hệ, một quyết định đang phân vân, người cũ, crush, mập mờ, nghỉ việc hay ở lại, con không chịu học.

## Cây chủ đề phát triển được [CHỐT]
- Bản thân: hiểu mình, điểm mạnh và yếu, pattern, cách ra quyết định.
- Tình yêu: bản thân khi yêu, hiểu người yêu, xung đột, tiếp tục hay dừng, thay đổi cách giao tiếp.
- Sự nghiệp: cách làm việc, vì sao chán việc, môi trường phù hợp, lựa chọn A/B, theo dõi sau lựa chọn.
- Con cái: hiểu đặc tính, quan sát thực tế, học tập, giao tiếp, cảm xúc. Chỉ dành cho phụ huynh, theo ranh giới trẻ em.
- Học tập: cách học, mục tiêu cụ thể, thói quen, thử phương pháp.
- Gia đình, mối quan hệ, quyết định: cùng xương sống, nội dung và điều kiện riêng.

## Series nội dung đề xuất [ĐỀ XUẤT]
- "Bạn có bao nhiêu số X?": trống → 1 lần → 2 lần → 3+ lần. Kết bằng lưu ý còn phải xem nguồn số và biểu hiện thực tế.
- Số chủ đạo: bản ngắn, trực quan, dễ chia sẻ. CTA dẫn vào xem.
- Hook theo nhu cầu: tình yêu, sự nghiệp, con cái, bản thân, quyết định cụ thể.

## Cấu trúc video [ĐỀ XUẤT]
Hook → con số hoặc đặc điểm → một insight → "nhưng chưa đủ để kết luận" → CTA (gửi tên và ngày sinh, hoặc đăng ký xem).

## Tránh [CHỐT]
- Cạnh tranh bằng calculator tự động ở giai đoạn đầu. Ưu tiên trải nghiệm "người này sẽ nói gì về chính mình".
- Hứa dự đoán, hứa thay đổi, hứa kết quả.

## Bộ thẻ PR theo chủ đề [ĐỀ XUẤT, đã có mẫu]
- BẢN THÂN: "Bạn là ai khi không phải làm hài lòng ai khác?"
- TÌNH YÊU: "Bạn là người như thế nào khi yêu?"
- SỰ NGHIỆP: "Công việc gì thực sự phù hợp với bạn?"
- CON CÁI: "Con bạn là một linh hồn như thế nào?" (chỉ dùng theo ranh giới trẻ em)
