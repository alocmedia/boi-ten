# Phụ huynh có con lớp 3–5

## Người mua
- [CHỐT] Ba mẹ là người đăng ký và chịu trách nhiệm. Con không tự đăng ký, không tự thanh toán.
- [CHƯA RÕ] Mẹ hay bố là người đăng ký chính.
- Độ tuổi con: khoảng 8–11.

## Băn khoăn thường gặp
- Con không chịu học, hoặc học một lúc rồi bỏ, dù đã nhắc nhiều lần.
- Làm được khi có người nhắc, bỏ dở khi không ai nhắc.
- Chưa biết nói ra điều mình muốn hay không muốn, nên hay cáu hoặc im lặng.
- Chơi với bạn nào thì hay bị kéo theo, hoặc khó kết bạn.
- Muốn hiểu con hơn nhưng cảm giác chỉ đang đoán.

## Điều cần tránh
- Hứa điểm số. Không có căn cứ.
- Gắn nhãn tính cách. Đây là nỗi lo lớn nhất.
- Phán xét cách nuôi con. Nói với ba mẹ như những người cùng quan sát.

## Quyền được biết của con
- [CHỐT] Con được nói rõ điều gì sẽ được chia sẻ lại với ba mẹ, theo độ tuổi.
- [CHƯA RÕ] Con có tham gia buổi trao đổi cùng ba mẹ không.

## Landing đã viết
- `than-so-hoc-cho-con-lop-3-5-landing.html` (bản hiện hành).

## Cần bổ sung
- [CHƯA RÕ] Giá và thời lượng. Chính sách lưu và xoá dữ liệu.
- [CHƯA RÕ] Phản hồi thật của phụ huynh, kèm đồng ý để đăng.
