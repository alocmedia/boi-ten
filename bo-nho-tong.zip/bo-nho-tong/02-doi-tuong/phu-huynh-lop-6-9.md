# Phụ huynh có con lớp 6–9

- [CHƯA LÀM] Chưa có chân dung riêng. Làm sau khi xong nhóm lớp 3–5.
- [ĐỀ XUẤT] Điểm khác cần nghiên cứu: chuyển cấp, bạn bè, con muốn tự quyết, áp lực thi cử, mâu thuẫn khi chọn hướng đi.
- [CHỐT] Ranh giới quan trọng nhất ở nhóm này: không chọn trường hay ngành thay con.
- [CHƯA RÕ] Lớp 8–9 có cần landing riêng, hay dùng chung với 6–7.
- [CHƯA RÕ] Với lớp 8–9, con có tự đăng ký không. Hiện trẻ không tự đăng ký (xem `00-ho-so/ranh-gioi-va-dao-duc.md`).
