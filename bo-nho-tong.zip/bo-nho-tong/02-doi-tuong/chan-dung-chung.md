# Chân dung khách chung

- [CHỐT] Đối tượng hiện tại: phụ huynh có con từ lớp 3 đến hết lớp 9.
- [ĐỀ XUẤT] Làm theo thứ tự: lớp 3–5, rồi lớp 6–7, rồi lớp 8–9.
- [CHƯA RÕ] Người mua chính: mẹ, bố, hay cả hai.
- [CHƯA RÕ] Nội dung 7 câu hỏi chân dung khách (tài liệu có nhắc, chưa có nội dung).
- [CHƯA RÕ] 25 câu hỏi phụ huynh hay hỏi (tài liệu có nhắc, chưa có file).

## Lý do họ tìm đến
- Sau một cuộc cãi vã về việc học.
- Khi con bỏ dở một việc đã cam kết.
- Khi chuẩn bị chuyển cấp hoặc chọn hướng đi.
- Khi thấy con khác đi về cảm xúc hoặc bạn bè.

## Rào cản mua hàng
- Hoài nghi về thần số học: cần thấy khung đọc có quy trình và giới hạn.
- Sợ con bị dán nhãn: ranh giới phải nói ngay đầu trang.
- Thời gian buổi tối: cần ba mẹ và con cùng tham gia được.
- Chi phí: chưa có giá.

## Không phải khách của dịch vụ
- Muốn chẩn đoán hoặc tìm nhãn cho con.
- Muốn dự đoán điểm số, nghề, hoặc dùng kết quả để quyết định thay con.
- Vấn đề tâm lý nghiêm trọng: chuyển chuyên gia, không đưa vào dịch vụ.

## Ngôn ngữ
- Nên: "điều ba mẹ đã thấy", "một giả thuyết để quan sát thêm", "thử một cách trò chuyện khác".
- Tránh: "con bạn là người như thế này", "thần số học cho biết con sẽ…", "con sẽ học giỏi hơn".
