# Thông tin thương hiệu và liên hệ

- [CHƯA RÕ] Tên thương hiệu và hệ nhận diện chính thức.
- [CHƯA RÕ] Người luận và kinh nghiệm công khai.
- [CHƯA RÕ] Kênh liên hệ chính thức: Zalo, Messenger, website, TikTok, Facebook.
- [CHƯA RÕ] Link đặt lịch.
- [CHƯA RÕ] Điều khoản huỷ, đổi lịch, hoàn tiền.
