# Rủi ro đang mở

1. Bảng 3×3 và nội dung số chưa đối chiếu. Luận 3×3 sớm là rủi ro lớn nhất.
2. Chưa có phản hồi thật được phép đăng.
3. Dữ liệu trẻ em: chưa có chính sách lưu và xoá, chưa có cơ chế đồng ý của phụ huynh.
4. Chưa có gói trả phí đầu tiên được định giá. Cửa vào miễn phí chưa có chỗ chuyển đổi rõ.
5. Chưa chốt kênh nhận khách và nơi lưu danh sách.
6. Khoá offline: phạm vi đến nhà, vai trò, quy trình an toàn chưa thoả thuận.
7. Quảng cáo nhắm người lớn, không nhắm tài khoản trẻ em.
8. Bot có nói rõ là AI hay không: cần quyết định và ghi rõ.
