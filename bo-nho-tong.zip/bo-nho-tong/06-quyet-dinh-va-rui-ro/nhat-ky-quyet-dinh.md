# Nhật ký quyết định

Ghi mới lên đầu. Không xoá dòng cũ. Dòng đổi ý: thêm dòng mới, đánh dấu dòng cũ là [ĐÃ THAY].

## Ca tự xem và cách đọc
- 2026-11-14 [CHỐT] Có thư mục `11-lich-su-cach-xem-chuan/` lưu ca tự xem của chủ, chỉ ở mức kỹ thuật và quyết định.
- 2026-11-14 [CHỐT] Ô trống là thiếu cầu nối, không phải thiếu giá trị. Không đọc thành cô đơn hay thiếu tình cảm.
- 2026-11-14 [CHỐT] Nghe chủ nói trước, rồi mới đối chiếu. Không hỏi dò cảm xúc khi chưa được mời.
- 2026-11-14 [CHỐT] Chi tiết khó khăn cá nhân không lưu trong repo.

## Bảng tra mũi tên
- 2026-11-14 [CHỐT] Có bảng tra mũi tên theo lưới 3×3 trong file tham chiếu. Lưu tại `bang-tra-mui-ten-3x3.md`.
- 2026-11-14 [CHƯA KIỂM CHỨNG] Tên của 5 trên 8 mũi tên là cách gọi thường gặp, chưa có trong nguồn.
- 2026-11-14 [CHƯA CHỐT] Các mô tả mức "nhiều" trong bảng tổng hợp phải viết lại dưới dạng quan sát.

## Lưới 3×3 và luận
- 2026-11-14 [CHỐT] Bảng tra 3×3 chỉ giúp khách điền số. Muốn luận, bot gợi ý các lựa chọn nâng cao.
- 2026-11-14 [ĐỀ XUẤT] Bot miễn phí: điền lưới, hiển thị số có và số thiếu, không luận mũi tên.
- 2026-11-14 [CHỐT] Không dùng các nhận định gắn nhãn hoặc chẩn đoán gián tiếp từ bản ghi video khoá học, kể cả khi có trong nguồn.

## Đối tượng và khách
- 2026-11-14 [CHỐT] Đối tượng hiện tại: phụ huynh có con lớp 3 đến lớp 9. Ưu tiên lớp 3–5.
- 2026-11-14 [CHỐT] Trẻ không tự đăng ký, không tự thanh toán. Ba mẹ chịu trách nhiệm.
- 2026-11-14 [CHỐT] Con được nói rõ điều gì sẽ được chia sẻ lại với ba mẹ.
- 2026-11-14 [CHỐT] Toàn bộ landing và bot tạm thời hướng đến phụ huynh xem cho con trước.

## Dịch vụ
- 2026-11-14 [CHỐT] XEM tùy tâm, có thể 0đ nếu khách thấy không phù hợp. Không đặt mức tối thiểu ngầm.
- 2026-11-14 [CHỐT] Không yêu cầu CCCD hay số định danh.
- 2026-11-14 [CHỐT] Không hỏi sâu khi khách chưa có đủ dữ liệu và kiến thức.
- 2026-11-14 [CHỐT] Không đổi TYPE giữa chừng khi chưa xác nhận lại.

## Hệ sinh thái
- 2026-11-14 [CHỐT] Hệ gồm bot miễn phí, bot nâng cao, khoá online (Zoom), khoá offline, khoá chuyên sâu.
- 2026-11-14 [CHỐT] Bot miễn phí và bot nâng cao khác nhau ở phần luận 3×3 và các link mở thêm.
- 2026-11-14 [CHỐT] Bot miễn phí: lời chào phân đối tượng, luận cơ bản (kim tự tháp, tính cơ bản), luôn gợi ý tư vấn riêng qua Zalo.
- 2026-11-14 [CHỐT] Bot nâng cao dành cho khách đã nhắn riêng hoặc đã xem buổi đầu, chưa mua đồng hành, chưa muốn chuyên sâu.
- 2026-11-14 [CHỐT] Khoá online: chỉ Zoom. Ba mẹ tự học, tự thực hành.
- 2026-11-14 [CHỐT] Khoá offline: thoả thuận lịch. Người đồng hành đến trực tiếp, giải thích vì sao con làm như vậy, hỗ trợ ba mẹ.
- 2026-11-14 [CHỐT] Khoá chuyên sâu chờ phân tích đối tượng.

## Nội dung và bằng chứng
- 2026-11-14 [ĐỀ XUẤT] Không luận 3×3 trong bot miễn phí cho đến khi bảng tra và nội dung số được đối chiếu.
- 2026-11-14 [ĐỀ XUẤT] Không đăng testimonial giả, số chỗ giả, cam kết kết quả.
- 2026-11-14 [ĐỀ XUẤT] Bằng chứng chỉ dùng khi có phản hồi thật và đồng ý để đăng.
- 2026-11-14 [ĐỀ XUẤT] Bot nói rõ mình là AI.
- 2026-11-14 [ĐỀ XUẤT] Quảng cáo chỉ nhắm người lớn.

## Tham chiếu
- 2026-11-14 [ĐỀ XUẤT] Mượn cấu trúc phễu và bài đăng từ bên làm mẫu. Không mượn lời hứa, số chỗ giả, cam kết kết quả, bot Zalo cá nhân, quản lý fanpage hộ.
