# Câu hỏi đang chờ người vận hành

## Hệ sinh thái
1. "L" trong khoá offline là ai: người đồng hành hay con?
2. "Kim tự tháp" là gì? Hình hay công cụ?
3. Bot nâng cao biết khách đã nhắn riêng hay đã xem buổi đầu bằng cơ chế nào?
4. Bot miễn phí chạy trên nền tảng nào: Zalo OA, Messenger, website, Telegram?
5. Zalo của người vận hành là tài khoản cá nhân hay Zalo OA?
6. Khoá online: số buổi, thời lượng, giá sơ bộ?
7. Khoá offline: phạm vi đến nhà, số lần, thời lượng, sĩ số?
8. Gói trả phí đầu tiên là gì, giá sơ bộ bao nhiêu?

## Đối tượng
9. Mẹ hay bố là người mua chính?
10. Con có tham gia buổi trao đổi cùng ba mẹ không?
11. Có file 25 câu hỏi phụ huynh hay hỏi không?
12. Có file 7 câu hỏi chân dung khách không?

## Bằng chứng và pháp lý
13. Có phản hồi thật nào được đồng ý để đăng không?
14. Chính sách dữ liệu và chính sách hoàn tiền, đổi lịch: có muốn tôi soạn bản nháp không?

## Nội dung
15. Bảng tra mũi tên: đã có trong `bang-tra-mui-ten-3x3.md`. Còn thiếu lưới trống và sơ đồ gốc để đối chiếu tên mũi tên. [CHƯA RÕ]
18. Cách tính chủ đạo: 4 ví dụ trong nguồn không khớp cách cộng. Cần chốt cách tính chính thức. [CHƯA RÕ]
16. Số chủ đạo 5, 6: có nguồn nào khác không?
17. Chữ Y được xử lý nguyên âm hay phụ âm trong hệ của bạn?
