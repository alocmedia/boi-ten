# Khảo sát thị trường huyền học Việt Nam

Phạm vi: Tarot, thần số học, tử vi, chiêm tinh, phong thủy. Quan sát cả reader cá nhân lẫn thương hiệu có website. Kênh: TikTok, Facebook, website.

## Mục đích [CHỐT]
Hiểu khách đang quen mua gì, thị trường tạo cửa vào thế nào, chia gói ra sao, khoảng giá ra sao. Không nhằm sao chép đối thủ.

## Cách thị trường bán [CHỐT, từ khảo sát]
1. Bán theo vấn đề khách đang quan tâm, không bán theo công cụ.
2. Dùng các nhu cầu quen thuộc làm cửa vào: tình duyên, người cũ, mập mờ, công việc, tài chính, gia đình, học tập.
3. Phân tầng: cửa vào rẻ hoặc miễn phí, phần đọc sâu trả phí, hỏi thêm, báo cáo, tư vấn trực tiếp.
4. Tăng giá trị cảm nhận bằng báo cáo PDF, bản tóm tắt, email luận giải, lượt hỏi lại, group kín, nhật ký, nhiều tháng đồng hành.
5. Reader cá nhân bán bằng cá tính và inbox. Thương hiệu chuyên nghiệp có website, menu gói, form đặt lịch, chính sách hoàn huỷ.
6. Một số bên dùng AI ở tầng rẻ, reader thật ở tầng cao.

## Khoảng giá tham khảo [CHƯA RÕ, chỉ là snapshot tại thời điểm khảo sát]
Không phải bảng giá chuẩn. Giá phụ thuộc hình thức, người cung cấp, thời lượng, mức cá nhân hoá, uy tín, trách nhiệm sau phiên.
- Tarot: 1 câu khoảng 49.000đ; 3 câu khoảng 99.000đ; theo phút khoảng 149.000–199.000đ; chuyên sâu khoảng 490.000đ; gói đồng hành theo tháng khoảng 699.000đ.
- Thần số học và coaching: sản phẩm số hoặc báo cáo từ khoảng 99.000 đến vài trăm nghìn; coaching 1:1 khoảng vài triệu; khoá nhiều buổi khoảng vài triệu đến vài triệu.

## Khác biệt định vị [CHỐT]
- Tarot mạnh ở câu hỏi hiện tại, tình cảm, lựa chọn.
- Tử vi, Bát Tự thường đóng gói thành lá số, vận trình, công danh, thời vận.
- Chiêm tinh dùng bản đồ sao và ngôn ngữ chu kỳ.
- Phong thủy thiên về không gian, hướng, thời điểm.
- Thần số học thường bán bằng hiểu bản thân, chỉ số, nghề, tình yêu, năm cá nhân.
- Dịch vụ này: dùng tên và thần số học để tạo giả thuyết, giải thích, đối chiếu với khách. Không cạnh tranh bằng lời hứa dự đoán.

## Bài học áp dụng [ĐỀ XUẤT]
- Chủ đề không quyết định cấu trúc sản phẩm. Cơ chế phục vụ mới là thứ cần tách rõ.
- Tài liệu phải phục vụ đúng chặng của khách, không nhồi nhiều trang.
- Không có "giá thị trường duy nhất". Định giá theo trách nhiệm người cung cấp nhận, khối lượng việc, scope và mức cam kết của khách.
