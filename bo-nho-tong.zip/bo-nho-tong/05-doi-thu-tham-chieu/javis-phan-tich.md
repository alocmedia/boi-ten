# Phân tích bên làm mẫu (Javis)

## Chuỗi họ dựng
1. Hook bằng nỗi đau cụ thể: tài liệu nằm trong Drive, dán lại bối cảnh mỗi lần.
2. Bằng chứng là hệ thống chạy thật: ảnh chụp, dashboard, phóng sự truyền hình.
3. Giá vào thấp, "giá trị" gốc cao làm mốc so sánh.
4. Bán nền trước (bộ não thứ 2).
5. Bundle tiện ích: Telegram ra lệnh, MCP nối dữ liệu, bot Zalo, content đa kênh.
6. Upsell dịch vụ: quản lý fanpage hộ. Khách đã có dữ liệu trong hệ thống nên khó rời.
7. Cộng đồng, học lại miễn phí, khoá sau.

## Cấu trúc bài đăng
- Hook đối lập hoặc nỗi đau. Bằng chứng ở giữa. Đơn giản hoá. CTA một từ khoá để comment, rồi nhắn riêng.
- Bằng chứng là ảnh chụp có khung đỏ, trích tin nhắn người thật.
- Tự hạ thấp để kéo gần người đọc. Mỗi bài một nhân vật.

## Đã mượn [ĐỀ XUẤT]
- Nỗi đau cụ thể làm hook.
- Phễu nhiều tầng, mỗi tầng có đầu ra rõ.
- CTA một hành động để phân loại người quan tâm.
- Bằng chứng từ phản hồi thật, có đồng ý.
- Mô tả một buổi cụ thể để người đọc hình dung mình trong đó.
- Mốc kết quả chia nhỏ trong khoá.

## Không mượn
- Cam kết kết quả, "làm hơn 80% công việc".
- Số chỗ giả, đếm ngược giá giả.
- Testimonial không xác minh, ảnh chụp chưa xin phép.
- Hoàn tiền hẹp đẩy rủi ro sang người học.
- Bot Zalo cá nhân: Zalo không hỗ trợ, có rủi ro khoá tài khoản.
- Quản lý fanpage hộ: rủi ro chính sách Meta.
- Luận cá tính trẻ em bằng bot: rủi ro gắn nhãn.

## Điểm khác có thể giữ
- Ranh giới đạo đức rõ, không dự đoán, không gắn nhãn trẻ em.
- Quy trình căn chỉnh và route rõ ràng.
- Khách dừng ở bất kỳ chặng nào, không ép upsell.
