# Phân tích ba bài đăng của bên làm mẫu

| Yếu tố | Bài 1: 6 kỹ năng | Bài 2: 7 clip mỗi tuần | Bài 3: Trợ lý chấm công |
|---|---|---|---|
| Hook | Đối lập: "AI không thay thế người, thay thế người chỉ chat" | Nỗi đau: "không biết dựng video" | Trích lời thành viên: "vợ dỗi vì chỉ nói chuyện với Javis" |
| Nỗi đau cụ thể | Copy câu trả lời rồi hỏi lại từ đầu | Clip 60 giây mất buổi tối | Chấm công, tính lương bằng Excel |
| Bằng chứng | Ví dụ ngắn, không số liệu thật | Ảnh chụp chat có khung đỏ | Trích tin nhắn, kèm tên người |
| Đơn giản hoá | "Không cần biết code" | "Chỉ viết một dòng" | Cùng câu trên |
| Cấu trúc | 6 mục đánh số, mỗi mục một dòng kết | 6 bước đánh số, mỗi bước một hành động | Câu chuyện, danh sách việc cũ, kết |
| CTA | Comment "JAVIS", nhắn riêng | Lưu bài, comment "JAVIS" | Comment "JAVIS" |

## Điểm chung [CHỐT, quan sát]
Nỗi đau trước, giải pháp sau, bằng chứng ở giữa, một từ khoá để comment ở cuối. Không có link, giá, hay lời hứa kết quả cụ thể.

## Chỗ đáng chú ý [CHỐT, quan sát]
- Từ khoá comment vừa là lời kêu gọi, vừa là cách phân loại người quan tâm.
- Khung đỏ dẫn mắt. Tên người trong ảnh thật, không xin phép công khai rõ ràng.
- Có câu không kiểm chứng: "làm hơn 80% công việc", "tự tìm hình, tự đọc giọng".
- Tự hạ thấp để kéo gần người đọc. Mỗi bài một nhân vật.

## Áp dụng cho dự án [ĐỀ XUẤT]
- Ba bài mở đầu: (1) đối lập không bói tương lai, (2) nỗi đau tình duyên, nhóm câu hỏi quan sát, (3) phản hồi thật, chỉ khi có đồng ý.
- CTA: comment từ khoá, rồi nhận hướng dẫn gửi họ tên và ngày sinh kèm thông báo về dữ liệu.
- Không dùng: "hiểu mình trong một buổi", "biết ngay điểm yếu", "con sẽ giỏi hơn", ảnh chụp chat chưa có đồng ý.
