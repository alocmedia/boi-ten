# Bản đồ công ty (business ontology)

Mục đích: cuốn "từ điển và luật chơi" để AI hiểu đúng công ty. Thay đổi ít. Làm chuẩn một lần, sửa khi có quyết định lớn.

Trạng thái chung: [ĐỀ XUẤT], vì đây là bản đầu tiên. Các mục đã dựa trên tài liệu gốc sẽ được gắn [CHỐT].

## 1. Thực thể (có gì)

| Thực thể | Là gì | Thuộc tính chính | Nguồn |
|---|---|---|---|
| Người quan tâm | Người mới biết đến dịch vụ | Nguồn vào (bot, bài đăng, giới thiệu), trạng thái (mới, đã nhắn riêng, đã xem, đã mua) | [ĐỀ XUẤT] |
| Khách | Người đã đăng ký dịch vụ | Vai trò: phụ huynh hoặc người lớn. Đối tượng đăng ký. Không lưu tên trẻ trong repo | [CHỐT] |
| Trẻ (thông tin) | Con của phụ huynh, nếu có | Họ tên, ngày sinh, lớp. Chỉ lưu khi có đồng ý của phụ huynh | [CHỐT] đồng ý; [CHƯA RÕ] chính sách lưu và xoá |
| Dịch vụ (DCV) | Một loại dịch vụ cụ thể | TYPE, mục tiêu đầu ra, điều kiện, giá | [CHỐT] TYPE; [CHƯA RÕ] giá |
| Phiên | Một buổi làm việc | Ngày, TYPE, người luận, tài liệu gửi, kết quả ghi nhận | [CHỐT] mẫu ghi nhận |
| Tài sản | Vật phẩm dùng trong dịch vụ | Bảng 3×3, thẻ, sổ quan sát, worksheet | [CHỐT] danh mục |
| Thanh toán | Khoản tiền khách trả | Số tiền, ngày, gắn với DCV, hình thức | [CHƯA RÕ] |
| Đồng ý dữ liệu | Sự cho phép lưu thông tin | Ai đồng ý, khi nào, phạm vi dùng | [ĐỀ XUẤT] |
| Phản hồi | Ý kiến khách sau phiên | Nội dung, có đồng ý đăng hay không, phạm vi dùng | [CHỐT] không đăng nếu chưa đồng ý |
| Quyết định | Việc đã chốt | Ngày, nội dung, file bị ảnh hưởng | Xem `06-quyet-dinh-va-rui-ro/` |

## 2. Quan hệ (cái nào dính cái nào)

- Người quan tâm → trở thành Khách khi đặt phiên hoặc thanh toán.
- Khách có nhiều Phiên. Mỗi Phiên thuộc một Dịch vụ.
- Dịch vụ có một TYPE.
- Phiên tạo ra hoặc dùng Tài sản.
- Thanh toán gắn với Dịch vụ, không gắn với Phiên.
- Phản hồi gắn với Phiên, chỉ dùng công khai khi có Đồng ý đăng.
- Thông tin trẻ gắn với Khách (phụ huynh), và chỉ được lưu sau khi có Đồng ý dữ liệu.

## 3. Luật (ai làm gì, khi nào, không làm gì)

### Luật về dịch vụ
- [CHỐT] Không đổi TYPE giữa chừng khi chưa xác nhận lại với khách.
- [CHỐT] Khách không làm bài mà chỉ muốn nghe giảng: route sang DẠY, không gọi là ĐỒNG HÀNH.
- [CHỐT] XEM tùy tâm: không đặt mức tối thiểu ngầm.
- [CHỐT] Khách không xác nhận mục đích: không hỏi sâu.
- [CHỐT] Không yêu cầu CCCD hay số định danh.
- [CHƯA CHỐT] Hoàn tiền, huỷ, đổi lịch.

### Luật về trẻ em
- [CHỐT] Trẻ không tự đăng ký, không tự thanh toán. Ba mẹ chịu trách nhiệm.
- [CHỐT] Không chẩn đoán, không gắn nhãn, không dự đoán điểm số, không chọn trường hay ngành thay con.
- [CHỐT] Con được nói rõ điều gì sẽ được chia sẻ lại với ba mẹ.
- [CHƯA RÕ] Chính sách lưu và xoá dữ liệu của con.

### Luật về nội dung
- [CHỐT] Không cam kết kết quả. Không đăng testimonial giả hoặc số chỗ giả.
- [CHỐT] Nhận định từ nguồn 4 và 5 không dùng làm kết luận về người khi chưa đối chiếu.
- [ĐỀ XUẤT] Bot nói rõ mình là AI.

## 4. AI được làm gì

### Được làm, không cần duyệt
- Soạn bản nháp tin nhắn, bài đăng, tài liệu.
- Tóm tắt phiên, ghi nhận vào `10-tri-nho-cong-ty/`.
- Đối chiếu một tình huống với các file trong repo.
- Nhắc việc, gợi ý bước tiếp theo theo router.
- Điền lưới 3×3 khi khách đã cung cấp họ tên và ngày sinh.

### Cần chủ công ty duyệt
- Gửi tin cho khách hoặc đăng công khai.
- Báo giá, nhận thanh toán, quyết định hoàn tiền.
- Đổi TYPE hoặc đổi nội dung dịch vụ.
- Đưa thông tin trẻ vào hệ thống.
- Đưa phản hồi khách ra công khai.

### Không được làm
- Dự đoán tương lai, quyết định thay khách, hứa kết quả.
- Gắn nhãn người, chẩn đoán, luận cá tính trẻ em.
- Luận 3×3 cho bot miễn phí khi bảng tra và cách tính chủ đạo chưa được xác nhận.

## 5. Vai trò trong công ty một người

- Hiện không có nhân viên. Phần việc nhân viên sẽ do AI đảm nhận theo mục 4, và chủ công ty là người duyệt.
- Khi tuyển thêm người, thêm thực thể "Nhân viên" với vai trò và quyền hạn, rồi cập nhật mục 3.
