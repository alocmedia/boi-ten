# Mục lục

| Thư mục / file | Nội dung | Trạng thái |
|---|---|---|
| `00-ho-so/vai-tro-va-pham-vi.md` | Vai trò, phạm vi, đối tượng, nguyên tắc | Đã có |
| `00-ho-so/ranh-gioi-va-dao-duc.md` | Không làm gì, ranh giới theo lĩnh vực, với trẻ em, về bằng chứng | Đã có |
| `00-ho-so/nguon-va-do-tin-cay.md` | Thứ tự ưu tiên nguồn, mức dùng, trạng thái tích hợp | Đã có |
| `00-ho-so/giong-van.md` | Giọng văn, nên và tránh | Đã có |
| `01-dich-vu-than-so-hoc/cac-type-dich-vu.md` | Sáu TYPE và cơ chế tiền | Đã có |
| `01-dich-vu-than-so-hoc/router-va-quy-trinh.md` | Router, quy trình buổi xem, hành trình, kiểm soát | Đã có |
| `01-dich-vu-than-so-hoc/cong-thuc-tao-dich-vu.md` | DOMAIN × TYPE × OUTCOME × CONDITIONS, quà theo cấp | Đã có |
| `01-dich-vu-than-so-hoc/nen-tang-tinh-chi-so.md` | Quy đổi chữ, rút gọn, chỉ số nền tảng, chu kỳ, nguồn | Đã có. Chữ Y và chỉ số bổ sung chưa chốt |
| `01-dich-vu-than-so-hoc/cau-hoi-va-luan-theo-so.md` | Từ khoá, mức tin cậy, 5W, ba khả năng, số chủ đạo | Đã có. Số 5, 6 chưa có nguồn |
| `01-dich-vu-than-so-hoc/nguon-video-khoa-hoc-3x3.md` | Nguồn video: có gì, thiếu gì, cảnh báo khi dùng | Đã có |
| `01-dich-vu-than-so-hoc/bang-tra-mui-ten-3x3.md` | Bảng tra mũi tên theo lưới, tổng hợp theo mức độ, cảnh báo cách tính | Đã có. Thiếu lưới trống và sơ đồ gốc |
| `01-dich-vu-than-so-hoc/bang-3x3-va-noi-dung-so.md` | Cách luận 3×3 và trạng thái nội dung số | Đã có. Thiếu bảng tra gốc |
| `01-dich-vu-than-so-hoc/tai-san-nhan-dien.md` | Tài sản giai đoạn đầu, tài liệu theo gói | Đã có |
| `01-dich-vu-than-so-hoc/tai-lieu-online-theo-goi.md` | Mẫu nhật ký, 7 ngày quan sát, bản đồ | Đã phác thảo |
| `02-doi-tuong/chan-dung-chung.md` | Chân dung chung, băn khoăn, rào cản | Đã có. Thiếu 7 câu chân dung |
| `02-doi-tuong/phu-huynh-lop-3-5.md` | Phụ huynh lớp 3–5 | Đã có |
| `02-doi-tuong/phu-huynh-lop-6-9.md` | Phụ huynh lớp 6–9 | Chưa làm |
| `02-doi-tuong/noi-dung-pr-va-cay-chu-de.md` | Chủ đề PR, cây chủ đề, series, cấu trúc video | Đã có |
| `03-he-sinh-thai/san-pham.md` | Bốn cửa vào, đường đi của khách | Đã có. Chi tiết sản phẩm còn thiếu |
| `03-he-sinh-thai/loi-chao-va-phan-doi-tuong.md` | Lời chào và luồng bot | Đề xuất |
| `03-he-sinh-thai/tai-san-va-bo-the.md` | Thư viện tài sản, bộ thẻ, thẻ giới thiệu | Đề xuất |
| `04-noi-dung-landing/danh-sach-landing.md` | Danh sách landing và trạng thái | Đã có |
| `04-noi-dung-landing/mau-bai-dang.md` | Cấu trúc bài đăng | Đề xuất |
| `05-doi-thu-tham-chieu/javis-phan-tich.md` | Chuỗi bán hàng, phần mượn, phần không mượn | Đã có |
| `05-doi-thu-tham-chieu/ba-bai-dang-phan-tich.md` | Phân tích ba bài đăng | Đã có |
| `05-doi-thu-tham-chieu/thi-truong-khao-sat.md` | Cách thị trường bán, khoảng giá snapshot, định vị | Đã có. Giá chỉ tham khảo |
| `06-quyet-dinh-va-rui-ro/nhat-ky-quyet-dinh.md` | Nhật ký quyết định | Đang cập nhật |
| `06-quyet-dinh-va-rui-ro/rui-ro.md` | Rủi ro đang mở | Đã có |
| `06-quyet-dinh-va-rui-ro/cau-hoi-mo.md` | Câu hỏi đang chờ | Đã có |
| `07-du-lieu-va-phap-ly/chinh-sach-du-lieu.md` | Khung chính sách dữ liệu | Chưa soạn chi tiết |
| `08-lien-he-thuong-hieu/thong-tin-chung.md` | Thương hiệu, liên hệ, điều khoản | Chưa có |
| `templates/` | Mẫu quyết định, landing, chân dung khách | Đã có |

## Không đưa vào repo, có chủ đích
- Ví dụ "hiểu con" về một cháu cụ thể trong tài liệu tham chiếu: thông tin về trẻ em cụ thể, theo quy ước không lưu.
- Số liệu chi tiết về phản hồi và ảnh chụp của bên làm mẫu: không có quyền đăng lại.

## Bản đồ và trí nhớ công ty (thêm mới)
| Thư mục / file | Nội dung | Trạng thái |
|---|---|---|
| `SO-DO-FILE.md` | Sơ đồ quan hệ giữa các file, luồng làm việc | Đã có |
| `09-ban-do-cong-ty/ontology.md` | Thực thể, quan hệ, luật, quyền AI | Đề xuất, bản đầu |
| `10-tri-nho-cong-ty/quy-trinh-gom.md` | Nguồn gom, nhịp gom, quy tắc ghi | Đề xuất. Chưa có inbox |
| `04-noi-dung-landing/truy-vet-landing-lop-3-5-qc.md` | Truy vết từng thành phần landing về file và dòng, việc cần làm trước khi chạy | Đã có |
| `00-ho-so/logic-truy-nguon.md` | Bốn loại nguồn, thứ tự tin cậy, cách kết hợp file, các lỗi đã sửa | Đã có |
| `11-lich-su-cach-xem-chuan/ca-tu-xem-nguoi-van-hanh.md` | Ca tự xem: kết quả kỹ thuật, cách đọc đã sửa, quyết định chia sẻ theo tầng | Đã có. Phạm vi lưu do chủ quyết định |
| `01-dich-vu-than-so-hoc/cach-xem-tong-hop.md` | Bản đồ toàn bộ cách xem: đầu vào, tính, đọc lưới, đọc số, luận, ghi nhận, phần còn thiếu | Đã có. Nên đọc đầu tiên |

