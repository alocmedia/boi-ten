# Bảng tra mũi tên theo lưới 3×3

Nguồn: file "Tham chiếu và kinh nghiệm các số" (bản `_1` giống hệt bản gốc, đã kiểm tra).
Trạng thái: [CHƯA KIỂM CHỨNG] với phần tên mũi tên và vị trí. Cần đối chiếu sơ đồ gốc trước khi dùng cho khách.

## Cách lưới được định nghĩa trong nguồn [CHỐT, theo tài liệu]
- Hàng trên: 1-4-7. Hàng giữa: 2-5-8. Hàng dưới: 3-6-9.
- Cột trái: 1-2-3. Cột giữa: 4-5-6. Cột phải: 7-8-9.
- Chéo: 1-5-9 và 3-5-7.
- Lưới có 8 mũi tên. Mỗi ô là một số, nên mỗi số thuộc một số mũi tên khác nhau tuỳ vị trí.

## Mũi tên và tên trong nguồn
| Mũi tên | Vị trí | Tên | Ghi chú nguồn |
|---|---|---|---|
| 1-4-7 | Ngang, hàng trên | Thực tế | Có tên trực tiếp trong nguồn |
| 2-5-8 | Ngang, hàng giữa | Tình cảm | Ngoài nguồn. Nguồn có nhắc "trục tâm hồn" |
| 3-6-9 | Ngang, hàng dưới | Trí tuệ | Ngoài nguồn |
| 1-2-3 | Dọc, cột trái | Kế hoạch / mục đích | Ngoài nguồn. Nguồn có nhắc "tục 123" |
| 4-5-6 | Dọc, cột giữa | Ký ức | Ngoài nguồn, chưa chắc |
| 7-8-9 | Dọc, cột phải | Hoạt động | Có tên trực tiếp trong nguồn |
| 1-5-9 | Chéo | Ý chí, quyết tâm | Ngoài nguồn. Nguồn có nhắc "quyết tâm" |
| 3-5-7 | Chéo | Tâm linh | Có tên trực tiếp trong nguồn |

[CHƯA KIỂM CHỨNG] Nguồn ghi: chỉ 1-4-7, 7-8-9 và 3-5-7 có tên trực tiếp. Các tên còn lại là cách gọi thường gặp, không lấy từ giáo trình.

## Mỗi số thuộc những mũi tên nào [CHỐT, tính từ lưới]
| Số | Số mũi tên | Các mũi tên |
|---|---|---|
| 1 | 3 | 1-4-7, 1-2-3, 1-5-9 |
| 2 | 2 | 2-5-8, 1-2-3 |
| 3 | 3 | 3-6-9, 1-2-3, 3-5-7 |
| 4 | 2 | 1-4-7, 4-5-6 |
| 5 | 4 | 2-5-8, 4-5-6, 1-5-9, 3-5-7 |
| 6 | 2 | 3-6-9, 4-5-6 |
| 7 | 3 | 1-4-7, 7-8-9, 3-5-7 |
| 8 | 2 | 2-5-8, 7-8-9 |
| 9 | 3 | 3-6-9, 7-8-9, 1-5-9 |

Quy luật: góc (1, 3, 7, 9) thuộc 3 mũi tên. Cạnh (2, 4, 6, 8) thuộc 2 mũi tên. Số 5 ở giữa thuộc 4 mũi tên.

## Cách dùng cho bot [ĐỀ XUẤT]
- Bot miễn phí: khách điền ngày sinh và tên vào lưới. Bot đếm số lần xuất hiện của từng số và liệt kê các mũi tên đầy đủ hoặc trống.
- Bot nâng cao: giải thích từng mũi tên trống hoặc đầy, kèm câu hỏi đối chiếu. Phần này chỉ dùng sau khi tên mũi tên đã được xác nhận.
- Không gọi một mũi tên trống là "thiếu năng lực". Không gắn nhãn người từ mũi tên.

## Tổng hợp theo mức độ (từ nguồn) [CHƯA CHỐT]
| Số | Thiếu | Có một | Nhiều |
|---|---|---|---|
| 1 | Không nêu | Khó nói ra cái tôi | Hai: ổn. Ba: hơi cao. Bốn trở lên: cực đoan (không gắn nhãn) |
| 2 | Không nêu rõ | Hiền, trực giác | Chưa rõ, cần chốt |
| 3 | Không nêu rõ | Ổn định | Hai: mơ mộng, xa thực tế |
| 4 | Thiếu cùng 5: uất giận | Một trong hai là ổn | Không nêu rõ |
| 5 | Khó diễn đạt nội tâm | Kết nối với mọi số | Không nêu rõ |
| 6 | Thiếu cùng 4, 5: mũi tên trống | Sáng tạo, gia đình | Không nêu rõ |
| 7 | Thiếu 4, 5, 8: ô trống cần lưu ý | Kiên trì, kỷ luật | Hai: dễ mất mát |
| 8 | Không nêu | Độc lập | Hai: không nhờ người giúp |
| 9 | Không nêu | Lý tưởng, quyền uy | Hai đến ba: kỳ vọng quá cao |

[CHƯA CHỐT] Các mô tả "nhiều" và "cực đoan" có thể gây gắn nhãn. Cần viết lại dưới dạng quan sát, không dùng nguyên văn.

## Vấn đề cần xử lý trước khi dùng [CHƯA RÕ]
Nguồn tự kiểm tra cách tính chủ đạo và thấy 4 ví dụ không khớp với cách cộng tất cả chữ số ngày, tháng, năm:
- 15/5/1993: cộng ra 33. Nguồn ghi 11.
- 28/12/2006: cộng ra 21, rút thành 3. Nguồn ghi 22.
- 22/2/2002: cộng ra 8. Nguồn ghi 10.
- 29/5/1973: cộng ra 36, rút thành 9. Nguồn ghi 7.

Nguồn đưa hai giải thích: bản ghi giọng nói sai, hoặc dùng cách tính khác. Chưa xác nhận được. Cách tính chủ đạo phải được chốt trước khi bot tính cho khách.

## Thứ chưa có trong file này [CHƯA RÕ]
- Lưới trống để khách điền.
- Quy tắc đặt ngày sinh và tên vào từng ô. Quy tắc quy đổi chữ đã có trong `nen-tang-tinh-chi-so.md`.
- Sơ đồ gốc để đối chiếu vị trí hàng, cột, chéo.
