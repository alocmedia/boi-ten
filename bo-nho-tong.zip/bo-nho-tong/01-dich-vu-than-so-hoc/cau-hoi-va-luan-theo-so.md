# Câu hỏi đối chiếu và cách luận theo số

Nguồn: tài liệu "Tham chiếu và kinh nghiệm các số" và tài liệu hệ thống dịch vụ.
Mọi nội dung là giả thuyết để kiểm chứng bằng đời thật, không phải kết luận về người.

## Cách đọc nhãn trong tài liệu gốc [CHỐT]
- "Ý nghĩa từ nguồn": nội dung từ bản ghi khoá học, có lỗi chuyển giọng nói.
- "Kinh nghiệm thực hành": quan sát của người thực hành, chưa kiểm chứng rộng.
- "Chờ kinh nghiệm": chưa có quan sát thực tế. Câu hỏi trong đó chỉ để thu thập, không phải kết luận.

## Tóm tắt từ khoá theo số [CHƯA RÕ, mức tin cậy ghi kèm]
| Số | Từ khoá trong nguồn | Mức tin cậy (theo tài liệu) |
|---|---|---|
| 1 | Cái tôi, tự chủ, chính kiến | Trung bình |
| 2 | Nhạy cảm, hoà đồng, trực giác | Trung bình |
| 3 | Sáng tạo, dễ mơ mộng | Thấp |
| 4 | Thực tế, tỉ mỉ | Thấp |
| 5 | Giao tiếp, kết nối | Trung bình |
| 6 | Gia đình, sáng tạo, nhớ lâu | Thấp |
| 7 | Kỷ luật, bài học cần vượt qua | Trung bình |
| 8 | Độc lập, ít kết nối | Trung bình |
| 9 | Quyền uy, lý tưởng, kỳ vọng cao | Trung bình |

## Quy tắc đọc số khi nhiều hoặc thiếu [CHỐT]
- Một số: nhẹ, cần đối chiếu.
- Nhiều số (từ bốn trở lên): nguồn nói cực đoan. Không dùng để gắn nhãn người.
- Số trống: không đồng nghĩa không làm được. Cần quan sát.

## Hai hướng cân bằng [ĐỀ XUẤT, chưa kiểm chứng]
- Hướng 1, cân bằng: thiếu số 5 và số 9 thì bổ sung; nhiều số 1 thì giảm.
- Hướng 2, làm chủ từng số: lấy số chủ đạo làm trọng tâm. Làm chủ một số rồi mới lần lượt làm chủ số khác.
- Chọn hướng theo mục tiêu của khách.

## Bộ câu hỏi 5W để luận từng trường hợp [CHỐT]
- Ai: người này thể hiện số đó ở đâu, với ai.
- Cái gì: số đó thể hiện ra hành vi cụ thể nào.
- Khi nào: số đó xuất hiện ở giai đoạn nào.
- Ở đâu: lĩnh vực nào (sự nghiệp, gia đình, sức khoẻ, tài chính, quan hệ).
- Vì sao: bài học hoặc nhu cầu nào đằng sau, và cần làm gì để làm chủ.

## Ba khả năng khi luận không khớp [CHỐT]
A. Khách chưa nhận ra. B. Hoàn cảnh chưa cho đặc tính biểu hiện. C. Luận giải không phù hợp với khách.
Cả ba đều được chấp nhận. Không ép khách nhận kết luận.

## Số chủ đạo [CHƯA RÕ, nội dung chưa đối chiếu]
- Số chủ đạo tính từ ngày sinh. Theo ghi chú của người dùng: có 2–9, 10, 11, 22 (22 rút thành 4). Không có 0 và 1.
- Ghi theo biểu đồ ngày sinh vì dễ kiểm chứng hơn.
- Các thiên hướng trong nguồn cho số chủ đạo 2, 3, 4 đã có. Số 5, 6 chưa tìm thấy trong nguồn đã tra.
- Mọi số chủ đạo: chờ kinh nghiệm, chưa đối chiếu.

## Câu hỏi thu thập [ĐỀ XUẤT]
Mỗi số có một vài câu hỏi để thu thập dữ liệu qua nhiều buổi. Đây là thu thập, không phải kết luận. Chi tiết cần chốt riêng.

## Không làm [CHỐT]
- Không kết luận người khác "bướng", "cứng đầu", "cô độc", "không biết lắng nghe", "không có chính kiến", "không có thế giới quan" chỉ từ một hoặc hai buổi.
- Không dùng số để đánh giá đúng sai trong suy nghĩ của người được xem.
- Không dùng các câu gắn nhãn mạnh từ nguồn.
