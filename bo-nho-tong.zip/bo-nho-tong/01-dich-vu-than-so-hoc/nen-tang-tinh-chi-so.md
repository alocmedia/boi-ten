# Nền tảng tính chỉ số (hệ Pythagoras)

Nguồn: tài liệu "Lý thuyết thần số học Pythagoras" của người dùng. Đây là quy ước của hệ đang dùng, không phải chuẩn khoa học duy nhất.

## Quy đổi chữ cái [CHỐT]
| Giá trị | Chữ cái |
|---|---|
| 1 | A, J, S |
| 2 | B, K, T |
| 3 | C, L, U |
| 4 | D, M, V |
| 5 | E, N, W |
| 6 | F, O, X |
| 7 | G, P, Y |
| 8 | H, Q, Z |
| 9 | I, R |

## Tên tiếng Việt [CHỐT, quy ước của hệ]
- Bỏ dấu thanh. Ă/Â → A, Ê → E, Ô/Ơ → O, Ư → U, Đ → D.
- Bỏ khoảng trắng khi đếm, nhưng giữ từng thành phần tên để kiểm tra tổng.
- Ví dụ: "Đỗ An" → DO AN. D=4, O=6, A=1, N=5. Tổng 16 → rút gọn 7. Nguyên âm O+A=7. Phụ âm D+N=9.
- [CHƯA RÕ] Chữ Y: quy ước cách xử lý trước khi tính Linh hồn và Nhân cách. Chưa chốt.

## Rút gọn [CHỐT]
- R1: cộng các chữ số đến 1–9. Ví dụ 28 → 10 → 1.
- RM: như R1 nhưng dừng khi gặp 11, 22, 33 ở bước được phép.
- Chu kỳ năm/tháng/ngày dùng R1. Đường đời dùng RM cho từng phần rồi RM tổng.
- Luôn ghi các bước để kiểm tra.

## Các chỉ số nền tảng [CHỐT]
- **Đường đời:** rút riêng tháng, ngày, năm theo RM. Cộng ba kết quả, rút tổng theo RM. Ví dụ giả định 15/08/1995: ngày 15 → 6; tháng 8; năm 1995 → 24 → 6; tổng 6+8+6 = 20 → 2. Đường đời = 2.
- **Ngày sinh:** ngày trong tháng, ghi thêm nền rút gọn (15 ghi 15/6; 11 ghi 11/2; 22 ghi 22/4). Không dùng tháng và năm.
- **Biểu đạt (Sứ mệnh):** quy đổi toàn bộ tên lúc sinh. Rút từng thành phần theo RM, cộng, rút tổng theo RM. Lưu tổng gốc để kiểm tra.
- **Linh hồn:** như Biểu đạt nhưng chỉ lấy nguyên âm đã xác định.
- **Nhân cách:** như Biểu đạt nhưng chỉ lấy phụ âm. Kiểm tra: tổng nguyên âm + tổng phụ âm = tổng toàn tên.
- Tên thường dùng khác tên lúc sinh: ghi riêng, không lặng lẽ thay thế.

## Chỉ số bổ sung [ĐỀ XUẤT, dùng sau khi nền tảng ổn định]
- Trưởng thành: RM(Đường đời + Biểu đạt).
- Thái độ: R1(ngày sinh + tháng sinh).
- Cân bằng: R1(tổng giá trị chữ đầu các thành phần tên).
- Đam mê tiềm ẩn: giá trị xuất hiện nhiều nhất trong tên (có thể đồng hạng).
- Bài học nghiệp: các giá trị 1–9 vắng trong tên đã quy đổi.
- Bản thân tiềm thức: 9 trừ số lượng giá trị thiếu.
- Lưu ý: số thiếu trong tên không phải số thiếu trong biểu đồ ngày sinh. Hai đầu vào khác nhau.

## Chu kỳ [ĐỀ XUẤT, dùng sau khi nền tảng ổn định]
- Năm cá nhân = R1(ngày + tháng sinh + năm khảo sát). Ví dụ 15/08 xét 2026: 15+8+2026 → 6.
- Tháng cá nhân = R1(năm cá nhân + tháng khảo sát). Ví dụ tháng 10: 6+10 → 7.
- Ngày cá nhân = R1(tháng cá nhân + ngày khảo sát). Ví dụ ngày 3/10: 7+3 → 1.
- Mốc năm: dương lịch. Có trường phái dùng mốc sinh nhật, phải ghi rõ khi so sánh.
- Chu kỳ là chủ đề biểu tượng, không phải dự báo sự kiện.

## Chu kỳ dài: đỉnh cao và thử thách [ĐỀ XUẤT, phần nâng cao]
- Đỉnh cao, với M, D, Y là tháng, ngày, năm đã rút: P1 = RM(M+D); P2 = RM(D+Y); P3 = RM(P1+P2); P4 = RM(M+Y).
- Mốc đầu thường là 36 trừ Đường đời đã rút một chữ số. Hai chặng sau mỗi chặng 9 năm.
- Thử thách, rút M, D, Y về một chữ số trước: C1 = |D−M|; C2 = |D−Y|; C3 = |C1−C2|; C4 = |M−Y|.
- Thống nhất cách tính tuổi và ranh giới trước khi trình bày.

## Chưa triển khai [CHỐT]
- Biểu đồ 3×3 và các cách bố trí khác (mũi tên, trục). Mỗi cách là một trường phái khác. Cần ghi rõ nguồn trước khi dùng.
- Số thiên thần, số điện thoại, số nhà, số may mắn: không tự động là phần bắt buộc.

## Mẫu ghi chép cho mỗi chỉ số [CHỐT]
Tên chỉ số · dữ liệu đầu vào · công thức · quy tắc số đặc biệt · ví dụ tự tính · chủ đề biểu tượng · câu hỏi đối chiếu · điều chỉ số không chứng minh · nguồn.

## Trật tự học [ĐỀ XUẤT]
1. Dữ liệu, bảng chữ, rút gọn.
2. Đường đời và Ngày sinh.
3. Biểu đạt, Linh hồn, Nhân cách, kiểm tra tổng.
4. Chủ đề từng số theo vị trí.
5. Ghép năm chỉ số, luyện hỏi phản hồi.
6. Chu kỳ ngắn, rồi chu kỳ dài và chỉ số phụ.
7. Biểu đồ 3×3 chỉ khi đã chọn nguồn cụ thể.

## Tiêu chí hoàn thành nền tảng [ĐỀ XUẤT]
- Tự tính được một hồ sơ minh hoạ.
- Giải thích được vì sao hai nguồn cho kết quả khác nhau.
- Không đổi quy tắc để tìm kết quả mong muốn.
- Tách được ý nghĩa biểu tượng khỏi năng lực thật.

## Nguồn tham khảo (dùng để kiểm tra quy tắc, không phải chứng nhận khoa học)
- Numerology.com: năm chỉ số nền tảng; Đường đời; Biểu đạt; số đặc biệt.
- World Numerology: các chủ đề 1–9; Linh hồn; các nhóm chỉ số; công thức bổ sung và chu kỳ; chương trình học mở rộng.
