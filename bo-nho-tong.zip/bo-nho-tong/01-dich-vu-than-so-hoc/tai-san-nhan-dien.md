# Tài sản nhận diện và tài liệu

## Giai đoạn đầu: thu hút và nhận diện [CHỐT]
- Bảng 3×3 cá nhân hai mặt. Mặt trước: số nổi bật. Mặt sau: chỗ khách ghi chú.
- Thẻ "Tên của bạn nói gì?": điểm vào dễ chia sẻ, nhắc rằng tên chỉ là điểm bắt đầu.
- Thẻ kết quả sau buổi: đã thấy, đã khớp, chưa khớp, nên quan sát thêm, câu hỏi tự suy ngẫm.
- Hướng dẫn đọc kết quả: con số là công cụ gợi mở, không phải nhãn cố định.

## Tài liệu theo gói, gửi online sau khi khách vào dịch vụ [CHỐT]
- Worksheet theo chủ đề: bản thân, tình yêu, con cái, sự nghiệp, học tập.
- Tracker, nhật ký quan sát, bài tập, review định kỳ.
- Bộ "7 ngày quan sát con" cho phụ huynh.

## Nguyên tắc
- [ĐỀ XUẤT] Không in nhiều tài liệu trước khi có khách. Mỗi tài liệu phải có chức năng trong quy trình.
- [CHỐT] Không gửi toàn bộ thư viện cho một khách. Chỉ gửi phần liên quan.
