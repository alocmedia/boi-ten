# Nguồn: bản ghi video khoá học về biểu đồ 3×3

Tệp gốc: `merged.txt` (bản ghi giọng nói tự động, gộp từ nhiều video, khoảng 1 MB).
Người giảng: Quỳnh Hương (kênh MQ Inspiration). Nói nền tảng là sách The Complete Book of Numerology của David A. Phillips.
Tác giả nêu khoảng 300 ca thực hành tại Việt Nam trong 6 tháng. [CHƯA KIỂM CHỨNG]

## Chất lượng bản ghi [CHỐT]
- Dịch tự động có lỗi. Ví dụ "mũi kênh" nghĩa là "mũi tên". Có đoạn cuối lẫn chữ hỏng.
- Phải đối chiếu với video gốc trước khi trích dẫn bất kỳ câu nào.

## Có trong file [CHỐT, dùng để tham chiếu]
- Số 1 và 2: lý tưởng khi thành cặp. Từ 3 đến 9: lý tưởng khi chỉ có một số.
- Ô trống: có thể thiếu đặc tính đó, cần bổ sung. Số thừa: đã vượt điểm cân bằng.
- Khái niệm mũi tên, tức các đường gồm ba số trong lưới. Các tên được nhắc trong bản ghi:
  - Trục trí tuệ 3-6-9.
  - Mũi tên 1-4-7, và mũi tên 7-8-9 gọi là mũi tên hoạt động.
  - Mũi tên 2-5-8, gọi là mũi tên cân bằng cảm xúc.
  - Mũi tên 4-5-6, khi trống gọi là mũi tên bực bội (frustration).
  - Mũi tên 3-5-7, gắn với tâm linh theo lời giảng.
  - Các mũi tên khác được nhắc tên không đầy đủ: trí nhớ, hoài nghi về cuộc sống, trí tuệ, quyết tâm, lập kế hoạch, nhạy cảm quá mức.
- Các hình thái đặc biệt:
  - "Đảo cô đơn": thiếu số 5 ở trung tâm, tạo khoảng trống hình chữ thập.
  - "Cây cô lập": số 3 không có số 6, 5 hoặc 2 bao quanh.
- Cách bổ sung số bằng hành động: số 5 qua biểu đạt và kết nối; số 6 qua việc gia đình và sáng tạo; số 9 qua kế hoạch nhỏ hằng ngày. Có nhắc đến thiền, yoga, cầu nguyện.
- Ví dụ chuyển tên sang số: "Mark" → M=4, A=1, R=9, K=2. Phù hợp bảng quy đổi Pythagoras trong repo.

## Không có trong file [CHƯA RÕ]
- Lưới 3×3 trống để khách điền.
- Bảng quy đổi chữ như một bảng riêng (chỉ có một ví dụ).
- Quy tắc đặt ngày sinh vào lưới (chỉ thấy qua ví dụ).
- Tên đầy đủ và vị trí của mọi mũi tên.
- Quy tắc quy đổi tên tiếng Việt.
- Mức tin cậy hoặc nguồn cho từng nhận định.

## Không dùng được cho dự án [CHỐT]
1. Nhiều nhận định khẳng định hậu quả tâm lý và hành vi theo số. Ví dụ: người có nhiều số 3 "cô đơn", "dễ phụ thuộc chất kích thích", "mất kết nối với thực tế", "không tin người khác". Đây là gắn nhãn và chẩn đoán gián tiếp. Vi phạm ranh giới trong `00-ho-so/ranh-gioi-va-dao-duc.md`. Không đưa vào bot, landing hay bài đăng.
2. Có ví dụ về một người cụ thể và về trẻ em cụ thể. Không lưu vào repo.
3. Số liệu "300 ca" và "hàng chục nghìn bệnh nhân" chưa kiểm chứng.
4. Lời khuyên thiền, yoga, cầu nguyện mang tính tôn giáo và y tế. Không đưa vào dịch vụ.
5. Đây là tác phẩm của người khác. Chỉ dùng để tham chiếu, không sao chép nguyên văn cho nội dung công khai.

## Điểm có thể tham khảo [ĐỀ XUẤT]
- Cách đọc theo ô trống và cặp số, như một khung đọc trung tính.
- Ý tưởng "bổ sung bằng hành động nhỏ" có thể chuyển thành gợi ý khác, không gắn với nhãn.
- Các mũi tên chỉ nên dùng khi đã đối chiếu với bảng tra gốc.
