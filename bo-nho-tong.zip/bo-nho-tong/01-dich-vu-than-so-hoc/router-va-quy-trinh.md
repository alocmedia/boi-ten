# Router và quy trình

## Router
| Dấu hiệu nhu cầu | TYPE |
|---|---|
| Chỉ tò mò, muốn xem thử | XEM |
| Thiếu kiến thức | DẠY |
| Có kiến thức, chưa làm được | THỰC HÀNH |
| Có một vấn đề cần làm rõ | GIẢI QUYẾT |
| Có đầu ra cụ thể | MỤC TIÊU |
| Có đầu ra, sẵn sàng thực hành theo thời gian | ĐỒNG HÀNH |
| Vượt phạm vi | Không nhận, hoặc chuyển người phù hợp |

Khách có thể bị route lại giữa chừng. Đổi TYPE thì xác nhận lại luật chơi.

## Quy trình một buổi xem
1. Hỏi mục đích và xin dữ liệu cần thiết.
2. Đồng bộ hệ quy chiếu: khách biết gì, khác hệ nào.
3. Giải thích quy ước đang dùng.
4. Kiểm tra lại phép tính.
5. Trình bày ngắn vai trò từng chỉ số.
6. Hỏi ví dụ khớp và không khớp.
7. Phân biệt diễn giải với dữ kiện. Chốt điều cần kiểm tra trong thực tế.

## Hành trình khách
Mục đích → kiến thức sẵn có → đồng bộ hệ quy chiếu → ý định → kỳ vọng và luật chơi → thông tin thiếu → kiến thức thiếu → đối chiếu → hiểu → lựa chọn → hành động → DCV tiếp theo nếu cần.

## Ba lớp kiểm soát
- Trước dịch vụ: căn chỉnh thông tin, kiến thức, ý định, kỳ vọng, phạm vi, giá.
- Trong dịch vụ: có thông tin mới, mục tiêu đổi, câu hỏi vượt scope thì dừng, làm rõ, xác nhận lại.
- Sau dịch vụ: đóng phiên. Mục tiêu đạt chưa, còn gì chưa xử lý, khách tự làm được chưa.

## Mẫu xác nhận trước dịch vụ
Bạn đang muốn: … | Mục tiêu lần này: … | Tôi sẽ: … | Tôi không: … | Bạn cần: … | Kết thúc khi: … | Phí/điều kiện: …
