# Bảng 3×3 và nội dung các số

## Cách luận đang dùng [CHỐT]
- Số xuất hiện nhiều: đặc tính có xu hướng mạnh hơn. Khi quá mức có thể thành điểm cản.
- Số xuất hiện ít: đặc tính có, cần đối chiếu mức biểu hiện với thực tế.
- Số trống: không đồng nghĩa "không làm được". Là phần cần quan sát, học, hoặc rèn tuỳ trường hợp.
- Số từ tên: có thể rõ ở một số bối cảnh, không nhất thiết bao trùm.
- Số từ ngày sinh: có xu hướng là nền biểu hiện rộng hơn.
- Số chủ đạo: chủ đề lớn quanh đó cuộc sống thường xoay.

## Trạng thái
- [CHƯA RÕ] Bảng tra 3×3 gốc không có trong dự án. Phải đối chiếu trước khi dùng cho khách.
- [CHƯA RÕ] Nội dung chuẩn cho số 1–9. Nhiều mục đang ở mức "tin cậy thấp" hoặc "chờ kinh nghiệm".
- [CHƯA RÕ] Mâu thuẫn trong nguồn: kỷ luật gắn số 7 hay số 8; số 2 và số 22 đếm thế nào.
- [CHƯA RÕ] Mũi tên, trục và chỉ số phụ nào chính thức nằm trong hệ.
- [ĐỀ XUẤT] Không luận 3×3 trong bot miễn phí cho đến khi bảng tra và nội dung số được đối chiếu.

## Quy tắc khi luận
- Luôn hỏi khách đối chiếu với đời thật. Không kết luận cố định về con người.
- Không dùng câu gắn nhãn mạnh từ nguồn để đánh giá người khác.
- Kết quả đối chiếu ghi là: khớp, chưa khớp, hoặc chưa đủ dữ liệu.

## Cập nhật: vai trò của bảng tra và cách luận [CHỐT, theo ý người vận hành]
- Bảng tra 3×3 chỉ giúp khách điền số vào lưới. Bảng tra không đủ để luận.
- Muốn luận được, bot cần gợi ý các lựa chọn nâng cao: xem mũi tên, ô trống, cặp số. Phần này thuộc bot nâng cao hoặc buổi riêng.
- [ĐỀ XUẤT] Bot miễn phí: nhận họ tên và ngày sinh, điền lưới, hiển thị số có và số thiếu, không luận mũi tên.

## Nguồn đã kiểm tra [CHỐT]
- File `merged.txt` là bản ghi video khoá học. Chi tiết xem `nguon-video-khoa-hoc-3x3.md`.
- File này không chứa bảng tra gốc. Bảng tra vẫn [CHƯA RÕ].

## Cập nhật: bảng tra mũi tên đã có [CHỐT, kiểm tra ngày người dùng tải lên]
- File "Tham chiếu và kinh nghiệm các số" có bảng mũi tên theo lưới: 8 mũi tên, mỗi số thuộc những mũi tên nào, và tổng hợp theo mức độ. Chi tiết xem `bang-tra-mui-ten-3x3.md`.
- Vẫn chưa có lưới trống để khách điền. Chưa có sơ đồ gốc để đối chiếu vị trí.
- Tên mũi tên: chỉ 3 tên có trong nguồn. Các tên còn lại [CHƯA KIỂM CHỨNG].
- Cách tính chủ đạo có 4 ví dụ không khớp. Phải chốt trước khi bot tính chủ đạo.
