# Cách xem: tổng hợp hiện có

Đây là bản đồ của toàn bộ cách xem. Mỗi phần chỉ ra file chi tiết. Trạng thái: [CHỐT] đã dùng được, [ĐỀ XUẤT] đang thử, [CHƯA KIỂM CHỨNG] cần đối chiếu, [CHƯA RÕ] còn thiếu.

## 1. Đầu vào
- Họ tên lúc sinh và ngày sinh. Không cần CCCD. [CHỐT]
- Cách xử lý chữ Y và số 0 trong ngày sinh: [CHƯA RÕ]
→ `00-ho-so/vai-tro-va-pham-vi.md`, `01/nen-tang-tinh-chi-so.md`

## 2. Tính chỉ số
- Quy đổi chữ, rút gọn R1 và RM, Đường đời, Ngày sinh, Biểu đạt, Linh hồn, Nhân cách. [CHỐT]
- Chỉ số bổ sung và chu kỳ năm, tháng, ngày. [ĐỀ XUẤT]
- Đỉnh cao và thử thách: [ĐỀ XUẤT], chỉ dùng cho phần nâng cao.
- Cách tính chủ đạo: [CHƯA RÕ]. Nguồn có 4 ví dụ không khớp cách cộng thông thường.
→ `01/nen-tang-tinh-chi-so.md`

## 3. Đọc lưới 3×3
- Ghép ngày sinh và tên vào lưới, đếm số xuất hiện. [CHỐT]
- Tám mũi tên và số thuộc mũi tên nào. [CHỐT, theo nguồn]
- Tên mũi tên: chỉ 1-4-7, 7-8-9, 3-5-7 có trong nguồn. Các tên khác [CHƯA KIỂM CHỨNG].
- Lưới trống để khách điền và sơ đồ gốc để đối chiếu: [CHƯA RÕ]
→ `01/bang-tra-mui-ten-3x3.md`, `01/bang-3x3-va-noi-dung-so.md`

## 4. Đọc từng số
- Từ khoá và mức tin cậy, quy tắc đọc khi nhiều hoặc thiếu. [CHỐT]
- Bộ câu hỏi 5W để đối chiếu với đời thật. [CHỐT]
- Ba khả năng khi không khớp: chưa nhận ra, hoàn cảnh chưa cho biểu hiện, luận giải không phù hợp. [CHỐT]
- Kinh nghiệm riêng cho từng số, không có trong nguồn đã tích hợp: [CHƯA LÀM]
→ `01/cau-hoi-va-luan-theo-so.md`

## 5. Cách đọc ô trống và mũi tên
- Ô trống là thiếu cầu nối, không phải thiếu giá trị. Không gắn nhãn. [CHỐT]
- Nguồn có hai hướng cân bằng: bổ sung số qua biểu đạt và kết nối, hoặc làm chủ số chủ đạo trước. [CHỐT, theo nguồn]
- Tách số 5 (biểu đạt, kết nối với người) và số 8 (kết quả, tác động). [GIẢ THUYẾT]
→ `11-lich-su-cach-xem-chuan/ca-tu-xem-nguoi-van-hanh.md`

## 6. Luận giải và đối chiếu
- Đưa giả thuyết, hỏi khách đối chiếu với đời thật. Không kết luận về người. [CHỐT]
- Đối chiếu theo ba nhãn: khớp, chưa khớp, chưa đủ dữ liệu. [CHỐT]
- Nghe người được xem nói trước, không hỏi dò cảm xúc khi chưa được mời. [CHỐT]
→ `00-ho-so/ranh-gioi-va-dao-duc.md`, `00-ho-so/giong-van.md`

## 7. Quy trình ghi nhận
- Nhật ký quyết định, mẫu ghi 3 tuần cho số 5, mẫu ghi chu kỳ cho số chủ đạo, mẫu ghi quyết định cho số 8. [ĐỀ XUẤT]
- Chu kỳ cá nhân và cách so sánh 2–3 chu kỳ. [ĐỀ XUẤT]
→ `11-lich-su-cach-xem-chuan/`, `10-tri-nho-cong-ty/quy-trinh-gom.md`

## 8. Những gì chưa có
1. Cách tính chủ đạo chính thức.
2. Lưới trống và sơ đồ gốc để đối chiếu mũi tên.
3. Kinh nghiệm riêng cho từng số.
4. Chữ Y và số 0 trong ngày sinh.
5. Bốn bước "đưa biểu đồ ra" trong dịch vụ (đang ở tài liệu gốc, chưa vào repo).

## 9. Nguyên tắc không đổi
- Không gắn nhãn người từ số. Không dự đoán. Không chẩn đoán.
- Mọi kết quả là giả thuyết để đối chiếu với đời thật.
- Nguồn không đủ chắc thì ghi [CHƯA KIỂM CHỨNG], không lấy làm kết luận.
