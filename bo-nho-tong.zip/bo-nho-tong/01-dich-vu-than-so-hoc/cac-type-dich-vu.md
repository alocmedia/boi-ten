# Sáu loại dịch vụ (TYPE)

| TYPE | Khách muốn | Cơ chế tiền | Điều kiện chính |
|---|---|---|---|
| XEM | "Xem tôi thử" | Tùy tâm sau khi xem. Có thể 0đ | Cung cấp dữ liệu, phản hồi thật, không bắt buộc bài tập |
| GIẢI QUYẾT | "Tôi đang có vấn đề X" | Giá cố định | Một vấn đề cụ thể. Đổi vấn đề thì xác nhận scope mới |
| MỤC TIÊU | "Tôi muốn đạt X" | Giá cố định | Xác định "sau dịch vụ cái gì phải khác" |
| DẠY | "Dạy tôi X" | Theo buổi | Người dạy chịu trách nhiệm truyền đạt rõ |
| THỰC HÀNH | "Tôi biết rồi nhưng chưa làm được" | Theo buổi hoặc case | Khách có nền. Thiếu nền thì route về DẠY |
| ĐỒNG HÀNH | "Đi cùng tôi trong quá trình" | Trả trước theo chặng | Mục tiêu, thời hạn, hành động, bài tập, review |

## Ghi chú
- [CHỐT] Không đổi TYPE giữa chừng khi chưa xác nhận lại luật chơi.
- [CHỐT] Khách không làm bài mà chỉ muốn nghe giảng: route sang DẠY, không gọi là ĐỒNG HÀNH.
- [CHƯA RÕ] Giá cụ thể từng TYPE.
- [ĐỀ XUẤT] Mentor cho người đã có nền: để sau, không đưa vào trang bán hàng hiện tại.
