# Công thức tạo dịch vụ

## Công thức [CHỐT]
DOMAIN × TYPE × OUTCOME × CONDITIONS = một DCV (dịch vụ riêng)

## Ví dụ đã thống nhất [CHỐT]
- Thần số học × XEM × Hiểu mình × Tùy tâm → Bói tên / Xem.
- Thần số học × DẠY × Đọc được biểu đồ 3×3 × Trả theo buổi → Dạy 3×3.
- Thần số học × ĐỒNG HÀNH × Tự luận được người thật × Trả trước + làm bài → Đồng hành học thần số học.
- Con cái × MỤC TIÊU × Tìm được cách giúp con chủ động làm X × Phụ huynh quan sát, ghi nhận → một DCV riêng.
- Tình yêu × GIẢI QUYẾT × Làm rõ một quyết định × Một vấn đề duy nhất → một DCV riêng.
- Tình yêu × ĐỒNG HÀNH × Thay đổi một pattern trong một khoảng thời gian × Bài tập, nhật ký, review → một DCV riêng.

## Mỗi chặng có thể là một DCV độc lập [CHỐT]
Biết/nhận diện → Hiểu → Một vấn đề → Một mục tiêu → Một hành động → Đồng hành → Tự vận hành (đích mong muốn).
Khách không bắt buộc đi hết. Không có "gói cao cấp hơn". Dịch vụ tiếp theo chỉ là next service khi nhu cầu mới thật sự phát sinh.

## Quà và tài liệu theo cấp dịch vụ [ĐỀ XUẤT]
- Xem tùy tâm: recap ngắn, có thể không cần workbook.
- Dịch vụ trả phí: bảng 3×3 cá nhân và thẻ liên quan.
- Giải quyết một vấn đề: thêm worksheet đúng vấn đề.
- Mục tiêu: goal sheet và tracker.
- Dạy: knowledge pack của buổi.
- Thực hành: case, feedback, đáp án sau khi làm.
- Đồng hành: workbook, tracker, review định kỳ.

## Mẫu xác nhận trước dịch vụ [CHỐT]
Bạn đang muốn: … | Mục tiêu lần này: … | Tôi sẽ: … | Tôi không: … | Bạn cần: … | Kết thúc khi: … | Phí/điều kiện: …
