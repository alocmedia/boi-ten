# Tài liệu online theo gói (chưa làm đại trà)

Nguyên tắc: gửi online sau khi khách vào đúng dịch vụ. Không gửi toàn bộ thư viện cho một khách.

## Mẫu đã phác thảo [ĐỀ XUẤT, chưa thiết kế chi tiết]
- Nhật ký quan sát một đặc tính: tình huống, việc đã làm, suy nghĩ, kết quả, giúp hay cản.
- "7 ngày quan sát con" (dành cho phụ huynh): con tập trung lâu nhất khi làm gì; tự bắt đầu việc gì không cần nhắc; phản ứng khi không thích; nhớ loại thông tin nào lâu; thích được khen kiểu nào; khi có mục tiêu rõ thì hành vi có đổi không; có điều gì khác hoàn toàn với luận giải ban đầu.
- Bản đồ "Tôi khi yêu": khi vui, khi bất an, khi xung đột, tôi cần người kia điều gì, điều khiến tôi khó chịu nhất, tôi thường quyết định thế nào, người yêu hay phàn nàn gì.
- Bản đồ "Tôi khi làm việc": việc khiến tôi vào flow, việc tôi trì hoãn, tự quyết hay nhận hướng dẫn, phản ứng với deadline, ổn định hay thay đổi, đồng nghiệp đánh giá cao gì, môi trường làm tôi mệt và môi trường giúp tôi tốt.
- Goal sheet, daily tracker, weekly review, progress report, end-of-program review.

## Trạng thái [CHƯA LÀM]
Chưa thiết kế xong. Bài tập và câu hỏi theo từng gói sẽ làm riêng và gửi online.
