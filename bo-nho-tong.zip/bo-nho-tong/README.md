# Bộ nhớ tổng: dự án thần số học và hệ sinh thái

Kho này lưu quyết định, cấu trúc sản phẩm, chân dung khách và tài liệu tham chiếu của dự án.
Mục tiêu: bất kỳ AI hay người nào đọc repo đều hiểu bối cảnh mà không cần hỏi lại từ đầu.

## Cách dùng
1. Với AI mới: dán nội dung `INDEX.md` và `CONVENTIONS.md`, rồi nói "đọc các file liên quan đến [chủ đề]". Hoặc tải cả repo nếu công cụ hỗ trợ đọc file.
2. Với người mới: đọc `INDEX.md`, rồi `00-ho-so/` và `01-dich-vu-than-so-hoc/`.
3. Khi có quyết định mới: ghi vào `06-quyet-dinh-va-rui-ro/nhat-ky-quyet-dinh.md` theo `templates/mau-quyet-dinh.md`, rồi cập nhật file chủ đề tương ứng.

## Nguyên tắc
- Mỗi thông tin có một nhãn: `[CHỐT]`, `[ĐỀ XUẤT]`, hoặc `[CHƯA RÕ]`. Xem `CONVENTIONS.md`.
- Một thông tin chỉ nằm ở một file chính. File khác chỉ tham chiếu bằng đường dẫn.
- Không lưu thông tin cá nhân của trẻ em hay khách cụ thể.
- Không đưa vào repo cam kết kết quả, testimonial chưa xác minh, hay số liệu chưa có nguồn.
