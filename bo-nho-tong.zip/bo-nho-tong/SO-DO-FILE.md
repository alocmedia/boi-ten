# Sơ đồ quan hệ giữa các file

```mermaid
graph TD
  subgraph BANDO["Bản đồ: ít đổi, làm chuẩn một lần"]
    A00["00-ho-so: vai trò, ranh giới, giọng văn, nguồn"]
    A01["01-dich-vu: TYPE, router, quy trình, 3×3, tài sản"]
    A02["02-doi-tuong: chân dung, PR"]
    A03["03-he-sinh-thai: sản phẩm, lời chào bot"]
    A09["09-ban-do-cong-ty: thực thể, quan hệ, luật, quyền AI"]
  end
  subgraph TRINHO["Trí nhớ: tăng mỗi ngày, gom định kỳ"]
    B10["10-tri-nho-cong-ty: inbox, gom theo tuần"]
    B06["06-quyet-dinh-va-rui-ro: nhật ký, rủi ro, câu hỏi"]
  end
  subgraph DAURA["Đầu ra: dùng để bán và giao việc"]
    C04["04-noi-dung-landing: landing, bài đăng"]
    C05["05-doi-thu-tham-chieu: phân tích, khảo sát"]
  end
  subgraph NGUON["Nguồn và quy định"]
    D07["07-du-lieu-va-phap-ly"]
    D08["08-lien-he-thuong-hieu"]
  end

  B10 -->|gom cuối tuần| B06
  B06 -->|quyết định mới| A01
  B06 -->|quyết định mới| A02
  B10 -->|tình huống lặp 3 lần| A09
  A09 -->|luật dịch vụ| A01
  A09 -->|quyền AI| A03
  A02 -->|chân dung| A03
  A01 -->|TYPE, router| C04
  A03 -->|sản phẩm, lời chào| C04
  A00 -->|ranh giới| C04
  C05 -.->|đối chiếu, nguồn phụ| A01
  D07 -.->|điều kiện thu thập| B10
  D08 -.->|kênh liên hệ| A03
```

## Cách đọc
- Nét liền: quan hệ trực tiếp. Nét chấm: đối chiếu hoặc điều kiện.
- Bản đồ (00, 01, 02, 03, 09) ít đổi. Trí nhớ (06, 10) đổi hằng ngày.
- Mọi thứ đi ra ngoài (04) phải đi qua bản đồ, không đi thẳng từ trí nhớ.

## Luồng làm việc một lần
1. Có việc mới trong ngày: ghi vào `10-tri-nho-cong-ty/inbox.md`.
2. Cuối tuần: chuyển sang nhật ký quyết định hoặc câu hỏi mở.
3. Nếu quyết định ảnh hưởng dịch vụ: cập nhật file trong `01` hoặc `02`.
4. Nếu quyết định là luật: cập nhật `09-ban-do-cong-ty/ontology.md`.
5. Chỉ sau đó mới viết lại landing hoặc bài đăng ở `04`.
