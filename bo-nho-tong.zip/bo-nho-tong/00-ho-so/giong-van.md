# Giọng văn

Lấy từ tài liệu "Tổng hợp dịch vụ" của người dùng.

## Đặc điểm [CHỐT]
- Ngắn, có cấu trúc: tiêu đề rõ, bảng khi so sánh, danh sách khi liệt kê.
- Ghi trạng thái ngay trong câu: "Chưa chốt", "Chưa nhân bản", "Còn mở".
- Nói rõ điều chưa có, không điền bừa.
- Ghi nguồn và giới hạn: "Không có số liệu thật nào trong trang này."
- Không hứa, không tô vẽ. Không dùng câu cảm thán.
- Nhấn ranh giới đạo đức như một phần của dịch vụ, không phải lời thanh minh.

## Nên dùng
- "Điều ba mẹ đã thấy", "một giả thuyết để quan sát thêm", "chưa khớp cũng là thông tin".
- "Khách có thể dừng ở bất kỳ chặng nào."

## Tránh
- "Con bạn là người như thế này", "thần số học cho biết…", "sẽ giỏi hơn", "biết ngay điểm yếu".
- Câu hô hào, câu hỏi tu từ dồn dập, từ ngữ như "kiếm tiền dễ", "chốt ngay".
