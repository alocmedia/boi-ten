# Ranh giới chuyên môn và đạo đức

## Không làm [CHỐT]
- Dự đoán chắc chắn tương lai.
- Quyết định thay khách, hoặc đảm bảo người khác làm theo ý khách.
- Dùng thần số học thay chẩn đoán tâm lý, y khoa, pháp lý, tài chính.
- Dùng số để kết luận về bệnh, tuổi thọ, khuyết tật, đầu tư.
- Chọn trường, chọn ngành, chọn nghề thay người khác.
- Gắn nhãn trẻ em hoặc người lớn từ biểu đồ.

## Khi vượt phạm vi [CHỐT]
Nói rõ: "Phần này đã vượt phạm vi của buổi xem." Dừng, hoặc gợi ý chuyên gia phù hợp.

## Ranh giới theo lĩnh vực [CHỐT]
- Đồng hành học tiếng Anh: hỗ trợ động lực, mục tiêu, quan sát, duy trì, phản tư. Sửa phát âm, ngữ pháp, giáo trình là chuyên môn giảng dạy.
- Đồng hành tình cảm: không phải trị liệu cặp đôi.
- Đồng hành con cái: không thay chuyên gia tâm lý hoặc giáo dục.
- Sự nghiệp: không đồng nghĩa biết mọi ngành nghề.

## Với trẻ em [CHỐT]
- Không chẩn đoán, không đặt giả thuyết về khuyết tật, rối loạn, bệnh lý từ biểu đồ.
- Không gắn nhãn. Không hứa điểm số.
- Không chọn trường hay ngành thay con.
- Trẻ không tự đăng ký, không tự thanh toán. Ba mẹ là người chịu trách nhiệm.
- Con được nói rõ điều gì sẽ được chia sẻ lại với ba mẹ.

## Tư cách người xem [CHỐT]
- Không yêu cầu CCCD hay số định danh.
- Không hỏi sâu khi khách chưa có đủ dữ liệu và kiến thức để suy nghĩ.
- Không dùng thần số học để đánh giá người khác.

## Về bằng chứng [ĐỀ XUẤT]
- Không đăng testimonial giả, số chỗ giả, cam kết kết quả.
- Chỉ dùng phản hồi thật khi có đồng ý để đăng, và ghi rõ phạm vi.
- Ví dụ minh hoạ trong tài liệu chỉ là minh hoạ, không phải bằng chứng hiệu quả.
