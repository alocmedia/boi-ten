# Vai trò và phạm vi

## Người vận hành
- [CHỐT] Người vận hành làm dịch vụ thần số học và xây hệ sinh thái sản phẩm quanh nó.
- [CHƯA RÕ] Tên thương hiệu và cách xưng hô công khai.

## Phạm vi dịch vụ
- [CHỐT] Khởi đầu bằng bói tên. Lõi là thần số học theo hệ Pythagoras.
- [CHỐT] Không định vị là dự đoán tương lai. Không quyết định thay khách.
- [CHỐT] Không thay thế chẩn đoán tâm lý, y khoa hay chuyên môn khác.
- [CHỐT] Khách cung cấp tối thiểu: họ tên lúc sinh và ngày, tháng, năm sinh. Không yêu cầu CCCD.

## Đối tượng hiện tại
- [CHỐT] Phụ huynh có con lớp 3 đến lớp 9. Chi tiết xem `02-doi-tuong/`.

## Nguyên tắc làm việc
- [CHỐT] Khách có thể dừng ở bất kỳ chặng nào. Không bán thêm chỉ vì có thể bán.
- [CHỐT] Mục tiêu hoặc phạm vi đổi giữa chừng: dừng, làm rõ, xác nhận lại.
- [CHỐT] Không gắn nhãn, không chẩn đoán, không dự đoán, đặc biệt với trẻ em.
