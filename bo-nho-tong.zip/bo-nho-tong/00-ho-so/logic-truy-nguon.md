# Logic truy nguồn: nội dung đến từ đâu, và cách các file kết hợp

Mục đích: mỗi thành phần trong bất kỳ sản phẩm nào (landing, bot, bài đăng) phải truy được về nguồn gốc. Nếu không truy được, thành phần đó không được đưa ra ngoài.

## 1. Bốn loại nguồn

| Loại | Là gì | Ví dụ | Cách dùng |
|---|---|---|---|
| A. Tài liệu gốc của người vận hành | File người dùng viết hoặc tải lên | `Tổng_hợp_dịch_vụ.html`, hai file docx, `Lý thuyết Pythagoras.md`, `Tham chiếu và kinh nghiệm các số.html` | Căn cứ chính |
| B. File tóm tắt trong repo | Bản tôi viết lại từ loại A, có thêm nhãn | Mọi file trong `00`–`10` | Dùng để làm việc hằng ngày. Luôn phải truy được về loại A |
| C. Nội dung tự soạn | Phần tôi viết từ logic, không có trong loại A | Tình huống "một buổi tối", lý do "cách cũ chưa đủ", các bước sau khi nhắn Zalo, FAQ | Gắn [ĐỀ XUẤT]. Cần người vận hành duyệt trước khi dùng |
| D. Mượn cấu trúc bên ngoài | Bố cục từ landing của bên làm mẫu | Thứ tự: hero, nghe quen không, khối giá trị, khối không làm | Chỉ mượn cấu trúc. Không mượn nội dung, số liệu, thủ thuật |

## 2. Thứ tự tin cậy khi các nguồn mâu thuẫn

1. Tài liệu gốc loại A có nhãn [CHỐT].
2. File trong repo có nhãn [CHỐT] và ghi rõ nguồn gốc.
3. Nội dung tôi soạn (C) với nhãn [ĐỀ XUẤT].
4. Nội dung tham chiếu có điều kiện, ví dụ `nguon-va-do-tin-cay.md`.
5. Bên ngoài (D).

Nếu hai nguồn mâu thuẫn, tôi ghi cả hai và đánh dấu "chưa thống nhất". Tôi không chọn bên có lợi hơn cho quảng cáo.

## 3. Cách các file kết hợp để ra một thành phần

Ví dụ: khối "Ba mẹ nhận được gì" trong landing lớp 3–5.
- Nội dung (sổ 7 ngày, nhật ký, thẻ kết quả, hướng dẫn đọc): lấy từ `01/tai-lieu-online-theo-goi.md` và `01/tai-san-nhan-dien.md`. Hai file này là bản tóm tắt của loại A.
- Đối tượng: lấy từ `02/phu-huynh-lop-3-5.md`.
- Ranh giới: lấy từ `00/ranh-gioi-va-dao-duc.md`, không lấy từ phần chỉ mô tả sản phẩm.
- Giọng văn: lấy từ `00/giong-van.md`.
- Ngôn từ CTA và cách trình bày: tự soạn (C), vì không có file nào quy định.

Quy tắc: một thông tin phải có một nguồn chính. Các file khác chỉ tham chiếu.

## 4. Những gì tôi đã làm sai khi truy vết (đã sửa trong bản ghi)

- Một số số dòng trích dẫn không đúng nội dung. Ví dụ: `router-va-quy-trinh.md` dòng 17–18 là các bước quy trình, không phải lý do khách không nói thật. `chan-dung-chung.md` dòng 18 là "thời gian buổi tối", không phải về quan sát.
- Tôi gán cho repo một số nội dung không có trong repo. Bốn bước "đưa biểu đồ ra" đến từ `Tổng_hợp_dịch_vụ.html` mục 2, chưa có trong repo.
- Tôi gán một số nội dung là "từ repo" trong khi thực ra là nội dung tự soạn. Ví dụ tình huống tối thứ Ba, lý do thứ hai trong "cách cũ chưa đủ", các bước sau khi nhắn Zalo.
- Phần FAQ trong landing được tổng hợp từ nhiều dòng khác nhau, không có dòng nào là FAQ gốc.

## 5. Quy tắc để không lặp lại

- Mọi thành phần sản phẩm phải ghi: loại nguồn (A, B, C, D), file, dòng.
- Khi tự soạn, ghi [ĐỀ XUẤT] ngay trong bản nháp.
- Không gán nội dung cho một file nếu file đó không chứa nội dung đó.
- Khi thiếu nguồn, để nhãn [CHƯA RÕ], không lấp bằng suy đoán.
