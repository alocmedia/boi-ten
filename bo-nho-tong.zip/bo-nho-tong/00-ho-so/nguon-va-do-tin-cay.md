# Nguồn và mức độ tin cậy

Dùng để quyết định khi nào được lấy một nhận định làm căn cứ, khi nào chỉ để tham khảo.

## Thứ tự ưu tiên

| Hạng | Nguồn | Vai trò | Mức dùng |
|---|---|---|---|
| 1 | `Ly_thuyet_than_so_hoc_Pythagoras.md` | Quy tắc tính, công thức, quy đổi chữ, rút gọn, chu kỳ | Căn cứ cho phép tính. Vẫn cần đối chiếu cách tính chủ đạo |
| 2 | Hai file docx "hệ thống dịch vụ" | Cấu trúc dịch vụ, TYPE, router, quy trình, ranh giới, tài sản | Căn cứ cho cách làm dịch vụ |
| 3 | `Tổng hợp dịch vụ.html` | Danh mục, trạng thái, luật chơi | Căn cứ cho trạng thái và giá "chưa chốt" |
| 4 | `Tham chiếu và kinh nghiệm các số.html` | Bảng mũi tên, mức tin cậy từng số, kinh nghiệm thực hành, câu hỏi thu thập | Tham chiếu có điều kiện. Mọi nội dung là giả thuyết, cần đối chiếu |
| 5 | `merged.txt` (bản ghi video) | Cách đọc lưới, ý nghĩa số, mũi tên, ví dụ | Nguồn phụ. Chỉ để đối chiếu, không dùng cho bất kỳ nhận định gắn nhãn nào |
| 6 | Trang web bên ngoài trong mục nguồn | Tham khảo cách tính và chủ đề | Chỉ đối chiếu khi cần giải thích quy ước |

## Quy tắc sử dụng [CHỐT]
- Nhận định về con người, đặc biệt trẻ em, không được lấy từ nguồn 4 hoặc 5 nếu không qua đối chiếu với đời thật.
- Nếu hai nguồn khác nhau, ghi cả hai và đánh dấu "chưa thống nhất". Không chọn bên có lợi hơn.
- Nội dung có mức tin cậy "thấp" hoặc "chờ kinh nghiệm" chỉ được xuất hiện như câu hỏi, không như kết luận.
- Ví dụ về người cụ thể không đưa vào repo, dù ở nguồn nào.

## Trạng thái tích hợp

### Đã tích hợp
- Quy đổi chữ, rút gọn, chỉ số nền tảng, chu kỳ: `01-dich-vu-than-so-hoc/nen-tang-tinh-chi-so.md` (nguồn 1).
- Bảng mũi tên, số thuộc mũi tên nào, tổng hợp theo mức độ: `01-dich-vu-than-so-hoc/bang-tra-mui-ten-3x3.md` (nguồn 4).
- Câu hỏi 5W, ba khả năng không khớp, từ khoá và mức tin cậy: `01-dich-vu-than-so-hoc/cau-hoi-va-luan-theo-so.md` (nguồn 4).
- Cách đọc lưới, các mũi tên được nhắc trong video, cảnh báo: `01-dich-vu-than-so-hoc/nguon-video-khoa-hoc-3x3.md` (nguồn 5).
- Ranh giới đạo đức, cấm gắn nhãn: `00-ho-so/ranh-gioi-va-dao-duc.md` (nguồn 2 và 4).

### Chưa tích hợp
- Kinh nghiệm thực hành của từng số 1–9 (bản chất, cách tiếp cận, hướng phản ứng). Nguồn 4. [ĐỀ XUẤT: đưa vào, dưới dạng câu hỏi đối chiếu.]
- Hai hướng cân bằng và làm chủ số. Nguồn 4. [CHƯA KIỂM CHỨNG: ghi là kinh nghiệm thực hành, không phải nguồn khoá học.]
- Bảng số chủ đạo 2–9 và các ghi chú "chờ kinh nghiệm". Nguồn 4. [CHƯA RÕ: cách tính chủ đạo còn mâu thuẫn.]
- Mẫu ghi kinh nghiệm: số và mức, bối cảnh, quan sát, phản ứng, đối chiếu, ghi chú. Nguồn 4. [ĐỀ XUẤT: dùng làm mẫu nhật ký, không dùng cho trẻ cụ thể.]
- Thứ tự đọc số theo vị trí trong video (đọc số 1 và 2 theo cặp, số từ 3 trở đi theo số đơn). Nguồn 5. [CHƯA KIỂM CHỨNG.]
- Bảng quy đổi chữ trong ví dụ "Mark" (M=4, A=1, R=9, K=2). Nguồn 5. Đã khớp với bảng quy đổi chính. [CHỐT]

### Không tích hợp
- Các nhận định gắn nhãn trong video: người có nhiều số 3 "cô đơn", "phụ thuộc chất kích thích", "mất kết nối thực tế". [CHỐT: không dùng.]
- Ví dụ "hiểu con" trong nguồn 4, về một trẻ cụ thể. [CHỐT: không đưa vào repo.]
- Các câu khuyên thiền, yoga, cầu nguyện như cách điều chỉnh số. [CHỐT: không đưa vào dịch vụ.]
- Các con số thống kê "300 ca" và "hàng chục nghìn bệnh nhân". [CHƯA KIỂM CHỨNG: không dùng.]

## Việc cần làm để nâng nguồn 4 và 5
1. Tìm sơ đồ gốc để đối chiếu vị trí hàng, cột, chéo và tên mũi tên.
2. Chốt cách tính chủ đạo, vì 4 ví dụ trong nguồn 4 không khớp cách cộng thông thường.
3. Quyết định có đưa phần kinh nghiệm từng số vào bot nâng cao hay không.
