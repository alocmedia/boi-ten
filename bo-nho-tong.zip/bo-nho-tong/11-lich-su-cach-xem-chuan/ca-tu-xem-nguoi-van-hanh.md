# Ca tự xem: người vận hành (lịch sử cách xem chuẩn)

Mục đích: ghi lại cách đọc một lưới đã được chủ tự đối chiếu, để dùng làm mẫu cho các lần sau. Đây là ca tự xem, không phải dữ liệu khách.

## Phạm vi lưu [CHỐT, do chủ quyết định]
- Lưu: dữ liệu kỹ thuật, kết quả đọc, cách sửa lại cách đọc, quyết định của chủ.
- Không lưu: chi tiết khó khăn cá nhân, cảm xúc sâu, danh sách người đã thử chia sẻ. Đây là thông tin nhạy cảm, không cần cho việc luận.
- Dữ liệu lúc sinh: lưu ở ghi chú riêng của chủ, không lưu trong repo.

## Kết quả đọc (kỹ thuật) [CHỐT]
- Đường đời 9, Ngày sinh 9, Biểu đạt 6, Linh hồn 5, Nhân cách 1. Tính theo `nen-tang-tinh-chi-so.md`.
- Lưới: số 5 trống. Số 4 và 8 cũng trống. Số 9 và 7 có mặt nhưng không nối được với nhau qua mũi tên có 5 (1-5-9, 3-5-7 đều thiếu 5).
- Mũi tên đầy đủ: 1-2-3 và 3-6-9.

## Cách đọc đã sửa [CHỐT]
- Ô trống 5 nghĩa là thiếu cầu nối giữa các chủ đề, không phải thiếu giá trị hay tình cảm.
- Không đọc ô trống thành mức cô đơn hay không được yêu thương. Đây là quy tắc trong `ranh-gioi-va-dao-duc.md`.
- Có thể chọn đọc theo hướng "cầu nối": ai tiếp cận được chủ đề nào, qua kênh nào. Phần này cần chủ tự xác nhận.

## Quyết định của chủ [CHỐT]
- Tạm ngưng chia sẻ chi tiết với người xung quanh.
- Chia sẻ theo tầng: nói chung trước. Chỉ đi sâu với người quan tâm hoặc cùng hướng.
- Không hiểu không đồng nghĩa không quan tâm hay yêu thương.

## Việc không làm với ca này [CHỐT]
- Không hỏi dò cảm xúc khi chủ chưa mời. Câu hỏi đối chiếu nên bám vào hành vi và ví dụ cụ thể.
- Không đoán mức độ cô đơn, không gắn nhãn.
- Không đưa ca này vào nội dung công khai, bài đăng, hay landing.

## Sai lầm đã ghi nhận [CHỐT]
- Trong lượt đầu, tôi hỏi về cảm xúc và đặt câu hỏi như thể cần tìm vấn đề. Đây không đúng với cách chủ đang dùng bản đồ. Quy tắc mới: nghe chủ nói trước, rồi mới đối chiếu.

## Trạng thái
- Chủ đang ở giai đoạn tạm ngưng chia sẻ chi tiết.
- Ca này không dùng để đánh giá chủ. Cập nhật khi chủ có ý kiến khác.

## Giả thuyết cân bằng số 5 [GIẢ THUYẾT, CHƯA KIỂM CHỨNG]
Chủ tự đề xuất, không phải kết luận của nguồn:
- Biểu hiện của 5: nói hàng giờ không mệt; làm điều mình muốn khi có người nghe; việc có liên quan đến chuyên môn đã tìm hiểu kỹ và mục tiêu rõ.
- Hướng đối chiếu: nguồn có hai hướng cân bằng (bổ sung 5 qua biểu đạt, hoặc làm chủ số chủ đạo trước). Hướng của chủ gần hướng làm chủ hơn.

Tách hai thứ đang bị gộp:
- Biểu đạt ra ngoài: nói, làm khi có người nghe.
- Chắc chắn bên trong: hiểu sâu chuyên môn, biết mình muốn gì.

Giả thuyết "phải giỏi chuyên môn thì 5 mới xuất hiện" chưa có căn cứ trong nguồn. Không dùng làm điều kiện.

## Mẫu ghi 3 tuần [ĐỀ XUẤT]
| Lúc đó đang làm gì, với ai | Nói bao lâu, có mệt không | Có liên quan chuyên môn đã tìm hiểu không | Có người tiếp nhận không |
|---|---|---|---|

Kết luận sau 3 tuần: khớp / chưa khớp / chưa đủ dữ liệu. Cả trường hợp nói không mệt nhưng không ai tiếp nhận đều là dữ liệu.

## Chuỗi suy luận về "tự điền số 5" [GIẢ THUYẾT, CHƯA KIỂM CHỨNG]
Chủ đề xuất: nắm chuyên môn và mục tiêu → biết nói gì, nói bao nhiêu, với ai → đó là biểu hiện của 5 → đã tự điền 5 (vô tình hay cố ý).

Điều cần lưu ý:
- Kiểm chứng bằng hành vi quan sát được, không bằng ý định. Ghi hành vi, không ghi lý do.
- Phải ghi cả phản hồi của người nghe. Biểu đạt mà không ai tiếp nhận là dữ liệu cần điều chỉnh giả thuyết.
- Không biến giả thuyết thành yêu cầu phải đạt. Ghi thêm: sau khi làm, chủ cảm thấy nhẹ hơn hay nặng hơn.

## Hướng tư vấn theo số chủ đạo [GIẢ THUYẾT, CHƯA KIỂM CHỨNG]
- Số chủ đạo: 9 (ngày sinh cộng ra 36 → 9, theo cách tính trong repo). Chú ý: cách tính chủ đạo còn mâu thuẫn ở nguồn, chỉ dùng tạm.
- Trục đề xuất: 9 và 7. Số 7 có mặt nhưng đứng riêng với 9 vì thiếu 5 (xem phần lưới ở trên).
- Chủ đề xuất hiện từ chủ tự kể: mục tiêu đến từ lý tưởng; thử nhiều; thất bại; lặp lại đến khi học được; tạm gác nhưng vẫn để đó.

Điều cần tránh khi đọc:
- Không so sánh mình với người khác ("lý tưởng hơn người khác"). Chỉ ghi chu kỳ của chính chủ.
- Không để việc "tạm gác" thành không có điều kiện quay lại.

## Mẫu ghi chu kỳ [ĐỀ XUẤT]
| Mục tiêu và điểm bắt đầu | Số lần thử, kết quả từng lần | Điều học được (một câu) | Vì sao gác, điều kiện quay lại |
|---|---|---|---|

Sau 2–3 chu kỳ: đối chiếu xem có mẫu chung không, và mẫu đó có khớp trục 9–7 không. Khớp / chưa khớp / chưa đủ dữ liệu.

## Số 8 và cách tách với số 5 [GIẢ THUYẾT, CHƯA KIỂM CHỨNG]
- Nguồn chỉ có từ khoá "độc lập" cho số 8, và ghi "không nêu" khi thiếu 8. Mọi ý khác là chủ tự đề xuất.
- Tách: số 5 là biểu đạt và kết nối với người. Số 8 là kết quả và tác động.
- Ý chủ tự đề xuất cho số 8: lợi ích; quyết đoán; muốn nhanh; không muốn cá nhân. Ghi riêng từng ý, không gộp. Lợi ích và muốn nhanh là kết quả. Quyết đoán là ra quyết định. Không muốn cá nhân là cách làm việc.

## Mẫu ghi quyết định cho số 8 [ĐỀ XUẤT]
| Quyết định | Ưu tiên gì (lợi ích / nhanh / cá nhân) | Có quyết đoán không | Kết quả |
|---|---|---|---|
Sau vài quyết định: ý nào lặp lại thì mới đưa vào định nghĩa. Ý nào không lặp lại thì không dùng.
