# Quy ước

## Nhãn trạng thái
- `[CHỐT]`: đã xác nhận, hoặc có trong tài liệu gốc. Được dùng để viết nội dung công khai.
- `[ĐỀ XUẤT]`: đề xuất, chưa xác nhận. Chưa dùng cho nội dung công khai.
- `[CHƯA RÕ]`: thiếu thông tin. Phải bổ sung trước khi viết liên quan.
- `[CHƯA LÀM]`: việc chưa bắt đầu.

## Quy tắc ghi
- Ghi ngày khi có quyết định mới, dạng `YYYY-MM-DD`.
- Khi đổi quyết định, không xoá dòng cũ. Thêm dòng mới và đánh dấu dòng cũ là `[ĐÃ THAY]`.
- Tên file: chữ thường, không dấu, nối bằng gạch ngang.

## Quy tắc về con người
- Không lưu tên, số điện thoại, ngày sinh của trẻ em hoặc khách cụ thể.
- Không lưu thông tin nhạy cảm của người khác (sức khoẻ, tài chính cá nhân).
- Phản hồi khách: chỉ lưu khi có đồng ý để đăng, và ghi rõ phạm vi được dùng.

## Quy tắc về nội dung
- Không ghi cam kết kết quả học tập hoặc thu nhập.
- Không ghi con số chưa có nguồn. Nếu có nguồn, ghi ngay bên cạnh.
- Mọi nội dung luận biểu đồ ghi là giả thuyết để kiểm chứng.

## Quy tắc cho ca tự xem
- Chỉ lưu dữ liệu kỹ thuật, kết quả đọc, cách sửa cách đọc, và quyết định của chủ.
- Không lưu chi tiết khó khăn cá nhân, cảm xúc sâu, hay danh sách người đã chia sẻ.
- Không hỏi dò cảm xúc khi chủ chưa mời.

