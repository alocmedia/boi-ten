# Truy vết landing quảng cáo lớp 3–5

File landing: `than-so-hoc-lop-3-5-qc.html` (đặt ở thư mục đầu ra, không nằm trong repo).
Mục đích: biết mỗi thành phần lấy từ đâu, để sửa đúng chỗ khi nguồn đổi.

Quy ước: đường dẫn là file trong repo. Số là số dòng. Nếu nguồn không có trong repo, ghi rõ "ngoài repo".

## Truy vết từng thành phần

| Thành phần trong landing | Nguồn | Dòng | Nhãn |
|---|---|---|---|
| Tiêu đề, đối tượng lớp 3–5 | `02-doi-tuong/chan-dung-chung.md` | 3, 4 | [CHỐT] lớp 3–9; [ĐỀ XUẤT] lớp 3–5 trước |
| Ba mẹ là người đăng ký | `02-doi-tuong/phu-huynh-lop-3-5.md` | 4 | [CHỐT] |
| Băn khoăn "làm được khi có người nhắc" | `02-doi-tuong/phu-huynh-lop-3-5.md` | 10 | Đã diễn đạt lại, bỏ "không chịu học" để tránh nhãn |
| Băn khoăn "chưa nói ra điều mình thích" | `02-doi-tuong/phu-huynh-lop-3-5.md` | 11 | Đã diễn đạt lại |
| Băn khoăn "chơi với bạn, bị cuốn theo" | `02-doi-tuong/phu-huynh-lop-3-5.md` | 12 | Đã diễn đạt lại |
| Băn khoăn "muốn hiểu con, cảm giác đoán" | `02-doi-tuong/phu-huynh-lop-3-5.md` | 13 | Đã diễn đạt lại |
| Bốn bước "đưa biểu đồ ra cùng ba mẹ" | Ngoài repo: `Tổng_hợp_dịch_vụ.html`, mục "Hiểu mình dựa vào biểu đồ" | — | [CHỐT] trong tài liệu gốc. **Chưa có trong repo, cần thêm** |
| Sổ "7 ngày quan sát con" | `01-dich-vu-than-so-hoc/tai-lieu-online-theo-goi.md` | 7 | [ĐỀ XUẤT] mẫu. Chưa thiết kế xong |
| Nhật ký quan sát một điều | `01-dich-vu-than-so-hoc/tai-lieu-online-theo-goi.md` | 6 | [ĐỀ XUẤT] |
| Thẻ kết quả sau buổi | `01-dich-vu-than-so-hoc/tai-san-nhan-dien.md` | 6 | [CHỐT] tài sản giai đoạn đầu |
| Hướng dẫn đọc kết quả | `01-dich-vu-than-so-hoc/tai-san-nhan-dien.md` | 7 | [CHỐT] |
| Ba mẹ đăng ký, con được biết điều gì được chia sẻ | `02-doi-tuong/phu-huynh-lop-3-5.md` | 4, 21 | [CHỐT] |
| Con được nói rõ điều được chia sẻ | `00-ho-so/ranh-gioi-va-dao-duc.md` | 25 | [CHỐT] |
| Thông tin chỉ dùng cho buổi, khi có đồng ý | `09-ban-do-cong-ty/ontology.md` | 13, 30 | [CHỐT] đồng ý; [CHƯA RÕ] chính sách lưu và xoá |
| Không chẩn đoán, không đặt giả thuyết bệnh | `00-ho-so/ranh-gioi-va-dao-duc.md` | 21 | [CHỐT] |
| Không gắn nhãn | `00-ho-so/ranh-gioi-va-dao-duc.md` | 22 | [CHỐT] |
| Không hứa điểm số | `00-ho-so/ranh-gioi-va-dao-duc.md` | 22 | [CHỐT] |
| Không thay giáo viên, chuyên gia | `00-ho-so/ranh-gioi-va-dao-duc.md` | 17 | [CHỐT] |
| Gợi ý chuyên gia khi vượt phạm vi | `00-ho-so/ranh-gioi-va-dao-duc.md` | 12 | [CHỐT] |
| Không cần CCCD | `00-ho-so/ranh-gioi-va-dao-duc.md` | 28 | [CHỐT] |
| Ba cách bắt đầu và cách tính phí | `01-dich-vu-than-so-hoc/cac-type-dich-vu.md` | 5, 7, 10 | [CHỐT] cơ chế; [CHƯA RÕ] giá |
| "Giúp con làm chủ một việc" = MỤC TIÊU | `01-dich-vu-than-so-hoc/cong-thuc-tao-dich-vu.md` | 10 | [CHỐT] công thức |
| "Đi cùng ba mẹ qua nhiều tuần" = ĐỒNG HÀNH | `01-dich-vu-than-so-hoc/cac-type-dich-vu.md` | 10 | [CHỐT] |
| "Xem thử" = XEM tùy tâm | `01-dich-vu-than-so-hoc/cac-type-dich-vu.md` | 5 | [CHỐT] |
| Câu hỏi "có đảm bảo học giỏi" | `00-ho-so/ranh-gioi-va-dao-duc.md` | 22 | [CHỐT] |
| Câu hỏi "không khớp thì sao" | `01-dich-vu-than-so-hoc/router-va-quy-trinh.md` | 22 (hỏi ví dụ khớp và không khớp) | [CHỐT] |
| Giọng văn: "điều ba mẹ đã thấy", "giả thuyết để quan sát" | `00-ho-so/giong-van.md` | 14 | [CHỐT] |
| Không dùng "kiếm tiền dễ", "chốt ngay" | `00-ho-so/giong-van.md` | 19 | [CHỐT] |
| Chữ "nhắn Zalo" làm CTA | `06-quyet-dinh-va-rui-ro/cau-hoi-mo.md` | 4, 5 | [CHƯA RÕ] Zalo cá nhân hay OA |

## Những thứ đã cố ý không đưa vào landing

| Thứ | Lý do | Nguồn |
|---|---|---|
| Bảng 3×3, mũi tên, tên số | Bảng chưa đối chiếu, tên mũi tên chưa kiểm chứng | `01-dich-vu-than-so-hoc/bang-tra-mui-ten-3x3.md`, `rui-ro.md` dòng 3 |
| Nhận định về "nhiều số 3", "cô đơn" | Gắn nhãn, không dùng | `05-doi-thu-tham-chieu/...`, `nguon-va-do-tin-cay.md` |
| Phản hồi phụ huynh | Chưa có phản hồi thật được phép đăng. Không dựng phần này khi chưa có | `rui-ro.md` dòng 4, `ranh-gioi-va-dao-duc.md` dòng 34 |
| Giá cụ thể, hoàn tiền | Chưa chốt | `cac-type-dich-vu.md` dòng 15, `ontology.md` dòng 40 |
| Số chỗ đợt sớm, đếm ngược | Đã ghi là không dùng | `ranh-gioi-va-dao-duc.md` dòng 33 |
| Ví dụ trẻ cụ thể | Thông tin về trẻ thật | `cau-hoi-mo.md` và `INDEX.md` |

## Việc phải làm trước khi chạy quảng cáo

1. Thêm bốn bước "đưa biểu đồ ra" vào repo (hiện chỉ có trong tài liệu gốc). Nếu không, landing dùng nội dung chưa có chỗ lưu.
2. Chốt giá và thời lượng ba cách bắt đầu. Đang là "Cần bổ sung".
3. Chốt chính sách lưu và xoá dữ liệu của con. Form đăng ký chưa thể có nếu chưa có câu đồng ý.
4. Chốt Zalo (cá nhân hay OA). Nút CTA đang chưa có đích.
5. Chốt chính sách hoàn tiền, vì câu hỏi "hoàn tiền thế nào" đang trống.

## Lưu ý khi chạy quảng cáo [ĐỀ XUẤT, kiểm tra với nền tảng trước khi chạy]

- Chỉ nhắm người lớn (phụ huynh). Không nhắm tài khoản trẻ em, không dùng ảnh trẻ em trong quảng cáo.
- Tiêu đề và câu quảng cáo không nói con đang có vấn đề, không gây sợ hãi về khuyết tật hay học kém.
- Không dùng ngôn ngữ so sánh con với bạn cùng lớp.
- Không dùng nhãn "giảm giá", "chỉ còn", "chốt ngay".
- Trang đích phải có câu ranh giới ngay phần đầu. Đã có trong landing (phần hero).
- Lưu lại phiên bản landing đã chạy để đối chiếu nếu có khiếu nại.

---

## Bản 2: truy vết theo cấu trúc landing chốt sale

Bản này thêm các khối cấu trúc mà landing chốt sale có. Mỗi khối lấy từ nguồn sau.

| Khối | Mục đích | Nguồn | Ghi chú |
|---|---|---|---|
| 1. Hero: câu hỏi nỗi đau + ranh giới | Đọc trong 3 giây hiểu đối tượng và điều không làm | `02-doi-tuong/chan-dung-chung.md` dòng 3; `00-ho-so/ranh-gioi-va-dao-duc.md` dòng 21–22 | Đã bỏ "con không chịu học", thay bằng mô tả cụ thể |
| 2. Nghe quen không? | Liệt kê tình huống cụ thể của ba mẹ | `02-doi-tuong/phu-huynh-lop-3-5.md` dòng 9–13 | Diễn đạt lại theo giọng trung tính |
| 3. Một buổi tối của ba mẹ | Kể một tình huống để người đọc thấy mình trong đó | `05-doi-thu-tham-chieu/javis-phan-tich.md` (mục "Mô tả một buổi cụ thể") và `03-he-sinh-thai/...` | Tình huống là giả định, ghi rõ. Không dùng ví dụ về trẻ thật |
| 4. Vì sao cách cũ chưa đủ (4 lý do) | Định vị vấn đề, không đổ lỗi ba mẹ | `02-doi-tuong/phu-huynh-lop-3-5.md` dòng 18 (cách quan sát chung), `01-dich-vu-than-so-hoc/router-va-quy-trinh.md` dòng 17–18 | Lý do 3 "hỏi con dễ bị đóng lại" là suy luận chung. [ĐỀ XUẤT] cần kiểm chứng |
| 5. Bốn bước đưa biểu đồ ra | Khung quy trình | Ngoài repo: `Tổng_hợp_dịch_vụ.html`, mục "Hiểu mình dựa vào biểu đồ" | **Vẫn chưa có trong repo** |
| 6. Ba mẹ nhận được gì | Giá trị thực của sản phẩm | `01-dich-vu-than-so-hoc/tai-lieu-online-theo-goi.md` dòng 6–7; `01-dich-vu-than-so-hoc/tai-san-nhan-dien.md` dòng 6–7 | Chỉ ghi thứ đã có. Không ghi giá trị ước tính |
| 7. Cách bắt đầu và cách tính phí | Lựa chọn cho khách | `01-dich-vu-than-so-hoc/cac-type-dich-vu.md` dòng 5, 7, 10 | Giá để trống, không đoán |
| 7b. Hai hình thức online và offline | Chọn theo nhu cầu | `03-he-sinh-thai/san-pham.md` dòng 7–8 | Offline còn thiếu phạm vi đến nhà |
| 8. Trong buổi và sau buổi có gì | Bảng giá trị (như "Trong gói có gì" của bên kia) | Các mục trên | Không có giá trị ước tính. Các dòng "có hay không" là [CHƯA RÕ] |
| 9. Những gì chúng tôi không làm | Thay cho "phần khó chúng tôi nhận về mình" | `00-ho-so/ranh-gioi-va-dao-duc.md` dòng 3–9, 21–25 | Đã đưa ranh giới lên thành khối riêng, có tính cam kết |
| 10. Ai đăng ký, con được biết gì | Quy trình đăng ký và quyền của con | `02-doi-tuong/phu-huynh-lop-3-5.md` dòng 4, 21; `09-ban-do-cong-ty/ontology.md` dòng 43–46 | Chính sách lưu xoá: [CHƯA RÕ] |
| 11. Người đồng hành | Giới thiệu người, không dựng thông tin giả | `09-ban-do-cong-ty/ontology.md` mục "Vai trò" | Tên và kinh nghiệm: [CHƯA RÕ] |
| 12. Phù hợp và chưa phù hợp | Lọc khách, giảm khiếu nại | `02-doi-tuong/chan-dung-chung.md` dòng 21–24 | Đã dùng nguyên ý |
| 13. Chuẩn bị trước buổi | Giảm rào cản | `ontology.md` mục "Thực thể" (Trẻ, Đồng ý dữ liệu); `02-doi-tuong/chan-dung-chung.md` dòng 18 | Thời gian buổi tối: [CHƯA RÕ] |
| 14. Ba điều bạn có sau mỗi bước | Thay "mốc kết quả" của bên kia | `01-dich-vu-than-so-hoc/router-va-quy-trinh.md` dòng 26 (hành trình) | Cố ý không hứa kết quả |
| 15. FAQ | Gỡ rào cản | `02-doi-tuong/phu-huynh-lop-3-5.md` dòng 16–22; `ranh-gioi-va-dao-duc.md` dòng 28–29 | Phần giá, hoàn tiền, thời lượng: [CHƯA RÕ] |
| 16. Sau khi nhắn Zalo | Thay "bấm vào là sang trang" | `ontology.md` mục "Quan hệ" và "Luật về trẻ em" | Bước 2 cần chính sách dữ liệu trước |
| 17. CTA cuối | Kết thúc có hành động | Đã lặp lại CTA ở hero và cuối trang | Không dùng đếm ngược, không dùng số chỗ giả |

### Khối đã cố ý bỏ, so với landing chốt sale

| Khối của bên kia | Lý do bỏ |
|---|---|
| Số chỗ đợt sớm, thanh đếm, "đủ 100 chỗ là tăng giá" | Số liệu giả, không dùng. Ghi trong `ranh-gioi-va-dao-duc.md` dòng 33 |
| Ảnh chụp phản hồi học viên, ảnh chat, đánh giá | Chưa có phản hồi thật được phép đăng. `rui-ro.md` dòng 4 |
| Hoàn tiền 3 ngày với điều kiện hẹp | Đây là cách đẩy rủi ro sang người mua. Chưa chốt chính sách của chúng ta. `ontology.md` dòng 40 |
| Giá trị "5.200.000đ" gạch ngang để so sánh | Không có giá trị thật để đưa vào |
| Quà tặng cho người đăng ký sớm | Chưa có quà nào được quyết định |
| "Cái giá của việc tự ôm hết" (so sánh thuê người) | So sánh này cần số liệu. Chưa có. Không đưa vào |
| "Chuyện có thật, kể thẳng" về bên bán lậu | Không đưa vào, không nói về đối thủ trong trang bán |

## Việc cần làm trước khi chạy (cập nhật)
1. Đưa bốn bước "đưa biểu đồ ra" vào repo, ở `01-dich-vu-than-so-hoc/`.
2. Chốt giá, thời lượng, số lần đồng hành, và chính sách hoàn tiền.
3. Chốt chính sách lưu và xoá dữ liệu của con.
4. Chốt Zalo (cá nhân hay OA).
5. Viết tên và kinh nghiệm người đồng hành, dựa trên thông tin thật.
6. Chốt phạm vi offline.


---

## Đính chính: các dòng trích dẫn sai và nguồn tự soạn

| Chỗ ghi trước | Thực tế | Sửa |
|---|---|---|
| "Lý do 3: hỏi con dễ bị đóng lại" ghi nguồn `router-va-quy-trinh.md` dòng 17–18 | Dòng 17–18 là bước quy trình, không nói về việc con đóng lại | Tự soạn [ĐỀ XUẤT], không có nguồn trong repo |
| "Cách quan sát chung" ghi nguồn `chan-dung-chung.md` dòng 18 | Dòng 18 là "Thời gian buổi tối" | Tự soạn [ĐỀ XUẤT] |
| "Lý do 4: lời khuyên chung không hợp" | Không có trong repo | Tự soạn [ĐỀ XUẤT] |
| Tình huống "Một buổi tối của ba mẹ" ghi nguồn `javis-phan-tich.md` | Javis chỉ gợi ý dùng mô tả buổi cụ thể. Nội dung tình huống là tự soạn | Tự soạn [ĐỀ XUẤT], tình huống giả định |
| FAQ ghi nguồn `phu-huynh-lop-3-5.md` dòng 16–22 | Dòng 16–18 là "điều cần tránh". FAQ không có trong file | Tổng hợp từ `ranh-gioi-va-dao-duc.md` dòng 22, 28–29 và `phu-huynh-lop-3-5.md` dòng 16. Phần còn lại tự soạn [ĐỀ XUẤT] |
| "Trong buổi có gì": nhóm hỏi đáp, bản ghi buổi | Không có trong repo | Tự soạn [ĐỀ XUẤT] và để [CHƯA RÕ] |
| "Sau khi nhắn Zalo, việc gì sẽ xảy ra" | Không có trong repo | Tự soạn [ĐỀ XUẤT]. Bước 2 cần chính sách dữ liệu |
| Bốn bước đưa biểu đồ ra | Từ `Tổng_hợp_dịch_vụ.html` mục 2 | Ghi nguồn ngoài repo. Cần đưa vào repo |
