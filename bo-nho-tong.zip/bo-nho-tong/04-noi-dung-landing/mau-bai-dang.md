# Mẫu bài đăng

## Cấu trúc đề xuất [ĐỀ XUẤT]
1. Hook: nỗi đau cụ thể hoặc câu hỏi đối lập.
2. Nội dung: ba câu hỏi để tự quan sát, hoặc một điều khách hay thấy.
3. Ranh giới: một dòng nói rõ không dự đoán, không gắn nhãn.
4. CTA: một hành động (comment từ khoá, hoặc nhắn riêng).

## Không dùng
- Cam kết kết quả.
- Ảnh chụp chat khi chưa có đồng ý rõ ràng.
- Số liệu chưa có nguồn.

## Trạng thái
- [CHƯA LÀM] Ba bài mở đầu. Chờ: kênh nhận khách, phản hồi được phép đăng, gói trả phí đầu tiên.
