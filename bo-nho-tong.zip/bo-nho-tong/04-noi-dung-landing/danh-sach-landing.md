# Danh sách landing

| File | Đối tượng | Trạng thái |
|---|---|---|
| `than-so-hoc-landing.html` | Người lớn, chốt sale | Có nhiều chỗ "Cần bổ sung" |
| `than-so-hoc-cho-con-lop-3-5-landing.html` | Phụ huynh có con lớp 3–5 | Bản hiện hành (trang đầy đủ) |
| `than-so-hoc-lop-3-5-qc.html` | Phụ huynh có con lớp 3–5, dùng để chạy quảng cáo | Bản nháp, chưa chạy. Chờ giá, Zalo, chính sách dữ liệu. Truy vết: `truy-vet-landing-lop-3-5-qc.md` |
| Bot miễn phí | Mọi người | [CHƯA LÀM] |
| Bot nâng cao | Khách đã nhắn riêng hoặc xem buổi đầu | [CHƯA LÀM] |
| Khoá online | Phụ huynh, muốn Zoom | [CHƯA LÀM] |
| Khoá offline | Phụ huynh, muốn gặp trực tiếp | [CHƯA LÀM] |
| Khoá chuyên sâu | Chưa xác định | [CHƯA LÀM] |
| Landing lớp 6–9 | Phụ huynh có con lớp 6–9 | [CHƯA LÀM] |

## Bản cũ, có thể bỏ
- `than-so-hoc-dich-vu.html`: bản tài liệu nội bộ, không phải landing.
- `than-so-hoc-cho-con-landing.html`: bản đối tượng rộng, đã thay bằng bản lớp 3–5.

## Quy tắc viết landing
- Mỗi landing có một đối tượng và một đầu ra.
- Không hứa kết quả. Ghi ranh giới ngay đầu trang.
- Chỗ chưa có thông tin: để nhãn rõ, không điền bừa.
- Không dùng phản hồi giả hoặc số chỗ giả.
